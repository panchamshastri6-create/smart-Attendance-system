"""tests/test_student.py — student registration module (add/edit/delete/search)."""

import pytest


def _create_student(client, **overrides):
    payload = {
        "full_name": "Asha Verma",
        "email": "asha@univ.edu",
        "enrollment_number": "CS23001",
        "department": "CSE",
        "semester": 3,
        "division": "A",
        "phone_number": "9876543210",
    }
    payload.update(overrides)
    return client.post("/api/students", json=payload)


def test_create_student_success(admin_client):
    resp = _create_student(admin_client)
    data = resp.get_json()
    assert resp.status_code == 201
    assert data["success"] is True
    assert data["student"]["enrollment_number"] == "CS23001"
    assert data["student"]["face_registered"] is False


def test_duplicate_enrollment_number_rejected(admin_client):
    _create_student(admin_client)
    resp = _create_student(admin_client, email="different@univ.edu")
    data = resp.get_json()
    assert resp.status_code == 400
    assert data["success"] is False
    assert "already exists" in data["message"]


def test_duplicate_email_rejected(admin_client):
    _create_student(admin_client)
    resp = _create_student(admin_client, enrollment_number="CS23002")
    data = resp.get_json()
    assert resp.status_code == 400
    assert data["success"] is False


def test_update_student(admin_client):
    student_id = _create_student(admin_client).get_json()["student"]["id"]
    resp = admin_client.put(f"/api/students/{student_id}", json={"department": "IT", "semester": 4})
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["student"]["department"] == "IT"
    assert data["student"]["semester"] == 4


def test_delete_student(admin_client):
    student_id = _create_student(admin_client).get_json()["student"]["id"]
    resp = admin_client.delete(f"/api/students/{student_id}")
    assert resp.status_code == 200

    followup = admin_client.get(f"/api/students/{student_id}")
    assert followup.status_code == 404


def test_search_student_by_name(admin_client):
    _create_student(admin_client)
    resp = admin_client.get("/api/students?q=Asha")
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["total"] == 1
    assert data["students"][0]["enrollment_number"] == "CS23001"


def test_non_admin_cannot_create_student(client):
    client.post("/login", data={"email": "admin@university.edu", "password": "Admin@123"})
    # Promote nobody; simulate a teacher trying to hit the admin-only create endpoint
    client.get("/logout")
    resp = client.post("/api/students", json={"full_name": "X"})
    assert resp.status_code == 401  # not authenticated at all
