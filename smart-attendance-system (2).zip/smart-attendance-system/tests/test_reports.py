"""tests/test_reports.py — report aggregation and CSV/Excel/PDF export."""

from services import report_service


def test_export_to_csv_produces_valid_bytes():
    rows = [{"a": 1, "b": "x"}, {"a": 2, "b": "y"}]
    buffer = report_service.export_to_csv(rows)
    content = buffer.getvalue().decode()
    assert "a,b" in content
    assert "1,x" in content


def test_export_to_excel_produces_valid_workbook():
    rows = [{"a": 1, "b": "x"}]
    buffer = report_service.export_to_excel(rows)
    assert len(buffer.getvalue()) > 0
    # XLSX files are zip archives; check for the zip magic number.
    assert buffer.getvalue()[:2] == b"PK"


def test_export_to_pdf_produces_valid_pdf():
    rows = [{"a": 1, "b": "x"}]
    buffer = report_service.export_to_pdf(rows, title="Test Report")
    assert buffer.getvalue()[:4] == b"%PDF"


def test_export_to_pdf_handles_empty_rows():
    buffer = report_service.export_to_pdf([], title="Empty Report")
    assert buffer.getvalue()[:4] == b"%PDF"


def test_student_percentage_report_via_api(admin_client):
    admin_client.post("/api/subjects", json={
        "subject_name": "Algorithms", "subject_code": "CS301", "semester": 5, "department": "CSE"
    })
    admin_client.post("/api/teachers", json={
        "full_name": "Prof. Iyer", "email": "iyer@univ.edu", "employee_id": "EMP010", "department": "CSE"
    })
    admin_client.post("/api/classrooms", json={"room_name": "Lab-2", "building_name": "IT Block"})
    student = admin_client.post("/api/students", json={
        "full_name": "Kiran Patel", "email": "kiran@univ.edu", "enrollment_number": "CS23099",
        "department": "CSE", "semester": 5, "division": "B",
    }).get_json()["student"]
    lecture = admin_client.post("/api/lectures", json={
        "subject_id": 1, "teacher_id": 1, "classroom_id": 1, "lecture_date": "2026-09-20",
        "start_time": "11:00", "end_time": "12:00", "semester": 5, "division": "B",
    }).get_json()["lecture"]
    admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "Manual Present"
    })

    resp = admin_client.get("/api/reports/student-percentage")
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["report"][0]["percentage"] == 100.0


def test_report_export_endpoint_csv(admin_client):
    resp = admin_client.get("/api/reports/export?format=csv")
    assert resp.status_code == 200
    assert resp.mimetype == "text/csv"
