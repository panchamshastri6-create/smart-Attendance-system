"""tests/test_rbac.py — role-based access control boundaries."""


def _make_teacher_and_student(admin_client):
    admin_client.post("/api/teachers", json={
        "full_name": "Prof. Iyer", "email": "iyer@univ.edu", "employee_id": "EMP010",
        "department": "CSE", "password": "Teach@123",
    })
    student = admin_client.post("/api/students", json={
        "full_name": "Kiran Patel", "email": "kiran@univ.edu", "enrollment_number": "CS23099",
        "department": "CSE", "semester": 5, "division": "B", "password": "Stud@123",
    }).get_json()["student"]
    other_student = admin_client.post("/api/students", json={
        "full_name": "Meera Nair", "email": "meera@univ.edu", "enrollment_number": "CS23100",
        "department": "CSE", "semester": 5, "division": "B",
    }).get_json()["student"]
    return student, other_student


def test_teacher_cannot_access_admin_only_routes(admin_client):
    _make_teacher_and_student(admin_client)
    admin_client.get("/logout")
    admin_client.post("/login", data={"email": "iyer@univ.edu", "password": "Teach@123"})

    assert admin_client.get("/teachers/new").status_code == 403
    assert admin_client.get("/settings").status_code == 403
    assert admin_client.get("/dashboard/teacher").status_code == 200


def test_student_cannot_access_admin_or_teacher_routes(admin_client):
    student, _other = _make_teacher_and_student(admin_client)
    admin_client.get("/logout")
    admin_client.post("/login", data={"email": "kiran@univ.edu", "password": "Stud@123"})

    assert admin_client.get("/dashboard/admin").status_code == 403
    assert admin_client.get("/students").status_code == 403
    assert admin_client.get("/dashboard/student").status_code == 200


def test_student_cannot_view_another_students_profile(admin_client):
    student, other_student = _make_teacher_and_student(admin_client)
    admin_client.get("/logout")
    admin_client.post("/login", data={"email": "kiran@univ.edu", "password": "Stud@123"})

    own_profile = admin_client.get(f"/students/{student['id']}")
    other_profile = admin_client.get(f"/students/{other_student['id']}")

    assert own_profile.status_code == 200
    assert other_profile.status_code == 403


def test_api_requires_authentication(client):
    resp = client.post("/api/students", json={"full_name": "X"})
    assert resp.status_code == 401
