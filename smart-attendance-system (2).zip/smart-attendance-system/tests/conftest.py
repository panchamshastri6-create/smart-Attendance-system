"""
tests/conftest.py
Shared pytest fixtures.

The heavy InsightFace/ONNX model is mocked at the lowest possible layer
(`ai_engine.face_detector.get_face_analysis_app`) so the full test suite
runs in seconds, offline, without downloading ~300MB of model weights.
Every OTHER layer (Flask routes, SQLAlchemy models, services, cosine
similarity matching, duplicate-resolution logic, embedding persistence,
report generation) is exercised for real — nothing about the business
logic is mocked, only the ONNX inference call itself.

To test against the REAL InsightFace model, delete the `mock_face_app`
autouse fixture below (or run with `--no-mock-ai`, see pytest.ini) once
the model weights have been downloaded on first run.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class _FakeInsightFaceApp:
    """Stands in for `insightface.app.FaceAnalysis`. By default it "detects"
    zero faces; individual tests can monkeypatch `.get` to return whatever
    fake Face objects they need."""

    def __init__(self, *args, **kwargs):
        pass

    def prepare(self, *args, **kwargs):
        pass

    def get(self, image):
        return []


@pytest.fixture(autouse=True)
def mock_face_app(monkeypatch):
    import ai_engine.face_detector as face_detector_module

    monkeypatch.setattr(face_detector_module, "_face_analysis_app", None)
    monkeypatch.setattr(face_detector_module, "get_face_analysis_app", lambda: _FakeInsightFaceApp())
    yield


@pytest.fixture
def app(tmp_path, monkeypatch):
    import config as config_module

    db_path = tmp_path / "test_attendance.db"
    config_module.TestingConfig.SQLALCHEMY_DATABASE_URI = f"sqlite:///{db_path}"
    config_module.TestingConfig.EMBEDDING_FOLDER = str(tmp_path / "embeddings")
    config_module.TestingConfig.BASE_UPLOAD_FOLDER = str(tmp_path / "uploads")
    config_module.TestingConfig.STUDENT_IMAGE_FOLDER = str(tmp_path / "uploads" / "students")
    config_module.TestingConfig.CLASSROOM_IMAGE_FOLDER = str(tmp_path / "uploads" / "classroom")
    config_module.TestingConfig.PROCESSED_IMAGE_FOLDER = str(tmp_path / "uploads" / "processed")
    config_module.TestingConfig.LOG_FOLDER = str(tmp_path / "logs")
    config_module.TestingConfig.LOG_FILE = str(tmp_path / "logs" / "app.log")

    monkeypatch.setenv("FLASK_ENV", "testing")

    from app import create_app

    flask_app = create_app(config_object=config_module.TestingConfig)
    yield flask_app


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin_client(client):
    client.post("/login", data={"email": "admin@university.edu", "password": "Admin@123"})
    return client
