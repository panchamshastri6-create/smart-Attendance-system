"""tests/test_auth.py — login/logout and default-admin seeding."""


def test_default_admin_seeded_and_can_log_in(client):
    resp = client.post(
        "/login", data={"email": "admin@university.edu", "password": "Admin@123"}, follow_redirects=True
    )
    assert resp.status_code == 200
    assert b"Admin Dashboard" in resp.data


def test_login_rejects_wrong_password(client):
    resp = client.post("/login", data={"email": "admin@university.edu", "password": "wrong-password"})
    assert resp.status_code == 401
    assert b"Invalid email or password" in resp.data


def test_api_login_returns_json(client):
    resp = client.post(
        "/api/auth/login", json={"email": "admin@university.edu", "password": "Admin@123"}
    )
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["success"] is True
    assert data["user"]["role"] == "admin"


def test_logout_clears_session(admin_client):
    resp = admin_client.get("/logout", follow_redirects=True)
    assert resp.status_code == 200
    # After logout, an authenticated-only page should bounce back to login.
    protected = admin_client.get("/dashboard/admin")
    assert protected.status_code in (302, 401)


def test_unauthenticated_user_redirected_from_dashboard(client):
    resp = client.get("/dashboard/admin")
    assert resp.status_code == 302
    assert "/login" in resp.headers["Location"]
