"""
tests/test_attendance.py
End-to-end attendance workflow: classroom-photo processing (with the
InsightFace layer mocked to 0 faces by the autouse fixture in conftest),
manual correction, duplicate-prevention, and lecture confirmation.
"""

import io

import cv2
import numpy as np


def _bootstrap_lecture(client):
    client.post("/api/subjects", json={
        "subject_name": "Algorithms", "subject_code": "CS301", "semester": 5, "department": "CSE"
    })
    client.post("/api/teachers", json={
        "full_name": "Prof. Iyer", "email": "iyer@univ.edu", "employee_id": "EMP010",
        "department": "CSE", "password": "Teach@123",
    })
    client.post("/api/classrooms", json={"room_name": "Lab-2", "building_name": "IT Block"})
    student = client.post("/api/students", json={
        "full_name": "Kiran Patel", "email": "kiran@univ.edu", "enrollment_number": "CS23099",
        "department": "CSE", "semester": 5, "division": "B",
    }).get_json()["student"]
    lecture = client.post("/api/lectures", json={
        "subject_id": 1, "teacher_id": 1, "classroom_id": 1, "lecture_date": "2026-09-20",
        "start_time": "11:00", "end_time": "12:00", "semester": 5, "division": "B",
    }).get_json()["lecture"]
    return student, lecture


def test_process_classroom_photo_with_zero_faces(admin_client):
    student, lecture = _bootstrap_lecture(admin_client)

    fake_img = np.zeros((480, 640, 3), dtype=np.uint8)
    ok, buf = cv2.imencode(".jpg", fake_img)

    resp = admin_client.post(
        "/api/attendance/process",
        data={"lecture_id": str(lecture["id"]), "image": (io.BytesIO(buf.tobytes()), "classroom.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["result"]["detected_faces"] == 0
    assert data["result"]["recognized"] == []


def test_manual_attendance_prevents_duplicate_rows(admin_client):
    student, lecture = _bootstrap_lecture(admin_client)

    r1 = admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "Manual Present"
    })
    assert r1.get_json()["attendance"]["status"] == "Manual Present"

    # Mark again with a different status -> should UPDATE the same row, not create a second one.
    r2 = admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "Absent"
    })
    assert r2.get_json()["attendance"]["status"] == "Absent"
    assert r1.get_json()["attendance"]["id"] == r2.get_json()["attendance"]["id"]

    roster = admin_client.get(f"/api/attendance/lecture/{lecture['id']}").get_json()["roster"]
    matching_rows = [r for r in roster if r["student_id"] == student["id"]]
    assert len(matching_rows) == 1
    assert matching_rows[0]["status"] == "Absent"


def test_confirm_attendance_marks_lecture_completed(admin_client):
    student, lecture = _bootstrap_lecture(admin_client)
    admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "Manual Present"
    })

    resp = admin_client.post("/api/attendance/confirm", json={"lecture_id": lecture["id"]})
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["lecture"]["status"] == "completed"


def test_invalid_status_rejected(admin_client):
    student, lecture = _bootstrap_lecture(admin_client)
    resp = admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "NotAStatus"
    })
    assert resp.status_code == 400


def test_reprocessing_confirmed_lecture_is_blocked(admin_client):
    student, lecture = _bootstrap_lecture(admin_client)
    admin_client.post("/api/attendance/manual", json={
        "lecture_id": lecture["id"], "student_id": student["id"], "status": "Manual Present"
    })
    admin_client.post("/api/attendance/confirm", json={"lecture_id": lecture["id"]})

    fake_img = np.zeros((100, 100, 3), dtype=np.uint8)
    ok, buf = cv2.imencode(".jpg", fake_img)
    resp = admin_client.post(
        "/api/attendance/process",
        data={"lecture_id": str(lecture["id"]), "image": (io.BytesIO(buf.tobytes()), "b.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 400
    assert "already been recorded" in data["message"]


def test_lecture_double_booking_rejected(admin_client):
    _student, lecture = _bootstrap_lecture(admin_client)
    resp = admin_client.post("/api/lectures", json={
        "subject_id": 1, "teacher_id": 1, "classroom_id": 1, "lecture_date": "2026-09-20",
        "start_time": "11:30", "end_time": "12:30", "semester": 5, "division": "B",
    })
    data = resp.get_json()
    assert resp.status_code == 400
    assert "already booked" in data["message"]
