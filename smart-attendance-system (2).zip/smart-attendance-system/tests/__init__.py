"""tests package: pytest suite for the AI Smart Attendance Management System."""
