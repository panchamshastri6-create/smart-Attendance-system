"""
tests/test_ai_engine.py
Tests the face-recognition MATH and DATA layer directly with synthetic
512-d embeddings — no image files or ONNX inference required, so these
run in milliseconds and don't depend on the mocked InsightFace app.
"""

import numpy as np
import pytest

from ai_engine import embedding_manager
from ai_engine.face_recognizer import FaceRecognizer, cosine_similarity


@pytest.fixture
def embedding_env(tmp_path, monkeypatch):
    from ai_engine import config as ai_config

    monkeypatch.setattr(ai_config, "EMBEDDING_FOLDER", str(tmp_path / "embeddings"))
    embedding_manager.invalidate_cache()
    yield
    embedding_manager.invalidate_cache()


def _unit(v):
    return v / np.linalg.norm(v)


def test_cosine_similarity_identical_vectors_is_one():
    v = _unit(np.random.default_rng(1).normal(size=512))
    assert cosine_similarity(v, v) == pytest.approx(1.0, abs=1e-5)


def test_cosine_similarity_orthogonal_vectors_near_zero():
    rng = np.random.default_rng(2)
    a = _unit(rng.normal(size=512))
    # Construct a vector orthogonal to `a`
    b = rng.normal(size=512)
    b = b - np.dot(b, a) * a
    b = _unit(b)
    assert abs(cosine_similarity(a, b)) < 0.15


def test_recognizer_matches_known_student(embedding_env):
    rng = np.random.default_rng(42)
    base = _unit(rng.normal(size=512))

    for i in range(3):
        noisy = _unit(base + rng.normal(scale=0.05, size=512))
        embedding_manager.save_embedding(1, noisy, f"sample_{i}.jpg")

    recognizer = FaceRecognizer(similarity_threshold=0.5, low_confidence_margin=0.05)
    probe = _unit(base + rng.normal(scale=0.03, size=512))
    result = recognizer.identify(probe)

    assert result.student_id == 1
    assert result.status in ("recognized", "low_confidence")


def test_recognizer_rejects_unknown_face(embedding_env):
    rng = np.random.default_rng(7)
    base = _unit(rng.normal(size=512))
    embedding_manager.save_embedding(1, base, "sample_0.jpg")

    recognizer = FaceRecognizer(similarity_threshold=0.6)
    random_face = _unit(rng.normal(size=512))
    result = recognizer.identify(random_face)

    assert result.student_id is None
    assert result.status == "unknown"


def test_duplicate_match_only_keeps_higher_confidence(embedding_env):
    rng = np.random.default_rng(9)
    base = _unit(rng.normal(size=512))
    embedding_manager.save_embedding(5, base, "sample_0.jpg")

    recognizer = FaceRecognizer(similarity_threshold=0.4)
    probe_close = _unit(base + rng.normal(scale=0.01, size=512))   # very close match
    probe_far = _unit(base + rng.normal(scale=0.15, size=512))     # weaker match, same student

    results = recognizer.identify_batch([probe_close, probe_far])
    recognized = [r for r in results if r.status == "recognized"]

    assert len(recognized) <= 1, "A student must never be double-counted from one photo"


def test_embedding_delete_removes_files(embedding_env):
    vec = _unit(np.random.default_rng(3).normal(size=512))
    embedding_manager.save_embedding(2, vec, "sample_0.jpg")
    assert len(embedding_manager.load_student_embeddings(2)) == 1

    embedding_manager.delete_student_embeddings(2)
    assert len(embedding_manager.load_student_embeddings(2)) == 0
