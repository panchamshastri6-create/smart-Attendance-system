"""
tests/test_face_registration.py
Exercises the /api/face/register validation pipeline: blur rejection,
no-face rejection, multiple-faces rejection, and successful acceptance
(with the InsightFace detection step monkeypatched per-scenario).
"""

import io

import cv2
import numpy as np
import pytest

from ai_engine.face_detector import DetectedFace, FaceDetector, MultipleFacesDetectedError, NoFaceDetectedError


def _create_student(client):
    payload = {
        "full_name": "Asha Verma",
        "email": "asha@univ.edu",
        "enrollment_number": "CS23001",
        "department": "CSE",
        "semester": 3,
        "division": "A",
    }
    return client.post("/api/students", json=payload).get_json()["student"]["id"]


def _fake_jpeg_bytes(size=(200, 200)):
    """A high-contrast checkerboard so the blur gate passes, letting tests
    isolate the face-detection branch instead of the blur-rejection branch."""
    img = np.zeros((size[1], size[0], 3), dtype=np.uint8)
    img[::8, :] = 255
    img[:, ::8] = 255
    ok, buf = cv2.imencode(".jpg", img)
    return buf.tobytes()


def test_register_rejects_when_no_face_detected(admin_client, monkeypatch):
    student_id = _create_student(admin_client)

    def raise_no_face(self, image):
        raise NoFaceDetectedError("No face detected in the uploaded image.")

    monkeypatch.setattr(FaceDetector, "detect_single_face", raise_no_face)

    resp = admin_client.post(
        "/api/face/register",
        data={"student_id": str(student_id), "image": (io.BytesIO(_fake_jpeg_bytes()), "face.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 422
    assert data["success"] is False
    assert "No face detected" in data["message"]


def test_register_rejects_multiple_faces(admin_client, monkeypatch):
    student_id = _create_student(admin_client)

    def raise_multi(self, image):
        raise MultipleFacesDetectedError("Please upload an image containing only one face.")

    monkeypatch.setattr(FaceDetector, "detect_single_face", raise_multi)

    resp = admin_client.post(
        "/api/face/register",
        data={"student_id": str(student_id), "image": (io.BytesIO(_fake_jpeg_bytes()), "face.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 422
    assert "only one face" in data["message"]


def test_register_accepts_valid_single_face(admin_client, monkeypatch):
    student_id = _create_student(admin_client)

    fake_face = DetectedFace(
        bbox=[10, 10, 150, 150],
        landmarks=np.zeros((5, 2)),
        det_score=0.99,
        embedding=np.random.default_rng(1).normal(size=512),
        normed_embedding=np.random.default_rng(1).normal(size=512),
    )

    def fake_detect_single(self, image):
        return fake_face

    monkeypatch.setattr(FaceDetector, "detect_single_face", fake_detect_single)

    # High-contrast checkerboard so the blur check passes.
    img = np.zeros((300, 300, 3), dtype=np.uint8)
    img[::8, :] = 255
    img[:, ::8] = 255
    ok, buf = cv2.imencode(".jpg", img)

    resp = admin_client.post(
        "/api/face/register",
        data={"student_id": str(student_id), "image": (io.BytesIO(buf.tobytes()), "face.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["success"] is True
    assert data["progress"]["captured"] == 1


def test_register_rejects_blurry_image(admin_client):
    student_id = _create_student(admin_client)
    # A perfectly flat, single-color image has ~zero Laplacian variance -> blurry.
    flat = np.full((200, 200, 3), 128, dtype=np.uint8)
    ok, buf = cv2.imencode(".jpg", flat)

    resp = admin_client.post(
        "/api/face/register",
        data={"student_id": str(student_id), "image": (io.BytesIO(buf.tobytes()), "face.jpg")},
        content_type="multipart/form-data",
    )
    data = resp.get_json()
    assert resp.status_code == 422
    assert "blurry" in data["message"].lower()


def test_face_registration_progress_endpoint(admin_client):
    student_id = _create_student(admin_client)
    resp = admin_client.get(f"/api/face/progress/{student_id}")
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["progress"]["captured"] == 0
    assert data["progress"]["is_complete"] is False
