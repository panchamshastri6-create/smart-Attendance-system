"""
extensions.py
Flask extension instances that need to be shared between app.py (where
they are initialized) and the route modules (where `csrf.exempt` is used
on pure-JSON API endpoints). Keeping them here avoids circular imports.
"""

from flask_wtf import CSRFProtect

csrf = CSRFProtect()
