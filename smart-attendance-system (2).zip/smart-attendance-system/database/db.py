"""
database/db.py
Central SQLAlchemy instance + helper to seed a default admin account.
"""

import logging

from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash

db = SQLAlchemy()
logger = logging.getLogger("smart_attendance")


def init_db(app):
    """Bind SQLAlchemy to the Flask app and create tables if missing."""
    db.init_app(app)
    with app.app_context():
        # Import models so they are registered on db.metadata before create_all
        from models import user, student, teacher, subject, lecture, attendance, settings  # noqa: F401

        db.create_all()
        seed_default_admin(app)


def seed_default_admin(app):
    """Create a default admin account on first boot if none exists."""
    from models.user import User

    existing_admin = User.query.filter_by(role="admin").first()
    if existing_admin:
        return

    default_email = app.config.get("DEFAULT_ADMIN_EMAIL", "admin@university.edu")
    default_password = app.config.get("DEFAULT_ADMIN_PASSWORD", "Admin@123")

    admin = User(
        full_name="System Administrator",
        email=default_email,
        password_hash=generate_password_hash(default_password),
        role="admin",
    )
    db.session.add(admin)
    db.session.commit()
    logger.info("Seeded default admin account: %s", default_email)
