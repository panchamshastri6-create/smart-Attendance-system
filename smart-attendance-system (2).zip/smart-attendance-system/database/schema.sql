-- =====================================================================
-- AI Smart Attendance Management System
-- Complete MySQL schema
-- Run:  mysql -u root -p < database/schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS smart_attendance_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE smart_attendance_db;

-- ---------------------------------------------------------------------
-- users : every login-capable person (admin / teacher / student)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(150)        NOT NULL,
    email           VARCHAR(150)        NOT NULL UNIQUE,
    password_hash   VARCHAR(255)        NOT NULL,
    role            ENUM('admin', 'teacher', 'student') NOT NULL,
    is_active       TINYINT(1)          NOT NULL DEFAULT 1,
    created_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- students : academic profile linked 1-1 to a user
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT             NOT NULL UNIQUE,
    enrollment_number   VARCHAR(50)     NOT NULL UNIQUE,
    department          VARCHAR(100)    NOT NULL,
    semester             INT             NOT NULL,
    division            VARCHAR(10)     NOT NULL,
    phone_number        VARCHAR(20),
    profile_image       VARCHAR(255),
    face_registered     TINYINT(1)      NOT NULL DEFAULT 0,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE,
    INDEX idx_students_dept_sem_div (department, semester, division)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- teachers : academic profile linked 1-1 to a user
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS teachers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT             NOT NULL UNIQUE,
    employee_id     VARCHAR(50)     NOT NULL UNIQUE,
    department      VARCHAR(100)    NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_teachers_user FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- subjects
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subjects (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    subject_name    VARCHAR(150)    NOT NULL,
    subject_code    VARCHAR(30)     NOT NULL UNIQUE,
    semester        INT             NOT NULL,
    department      VARCHAR(100)    NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- classrooms
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS classrooms (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    room_name       VARCHAR(100)    NOT NULL,
    building_name   VARCHAR(100)    NOT NULL,
    capacity        INT             DEFAULT 0,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_room_building (room_name, building_name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- lectures : one scheduled/ad-hoc class session
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lectures (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    subject_id      INT             NOT NULL,
    teacher_id      INT             NOT NULL,
    classroom_id    INT             NOT NULL,
    lecture_date    DATE            NOT NULL,
    start_time      TIME            NOT NULL,
    end_time        TIME            NOT NULL,
    semester        INT             NOT NULL,
    division        VARCHAR(10)     NOT NULL,
    status          ENUM('scheduled', 'completed', 'cancelled') NOT NULL DEFAULT 'scheduled',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_lectures_subject   FOREIGN KEY (subject_id)   REFERENCES subjects(id)   ON DELETE CASCADE,
    CONSTRAINT fk_lectures_teacher   FOREIGN KEY (teacher_id)   REFERENCES teachers(id)   ON DELETE CASCADE,
    CONSTRAINT fk_lectures_classroom FOREIGN KEY (classroom_id) REFERENCES classrooms(id) ON DELETE CASCADE,
    INDEX idx_lectures_date (lecture_date),
    INDEX idx_lectures_sem_div (semester, division)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- attendance : one row per student per lecture (never duplicated)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    student_id          INT             NOT NULL,
    lecture_id          INT             NOT NULL,
    status              ENUM('Present', 'Absent', 'Manual Present', 'Pending') NOT NULL DEFAULT 'Pending',
    confidence_score     FLOAT           DEFAULT NULL,
    detection_method    ENUM('AI', 'Manual') NOT NULL DEFAULT 'AI',
    marked_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    marked_by           INT             DEFAULT NULL COMMENT 'user_id of teacher/admin who confirmed/edited',
    CONSTRAINT fk_attendance_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_attendance_lecture FOREIGN KEY (lecture_id) REFERENCES lectures(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_student_lecture (student_id, lecture_id),
    INDEX idx_attendance_lecture (lecture_id),
    INDEX idx_attendance_student (student_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- face_data : one row per captured registration image + its embedding
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS face_data (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    student_id          INT             NOT NULL,
    image_path          VARCHAR(255)    NOT NULL,
    embedding_path       VARCHAR(255)    NOT NULL,
    quality_score        FLOAT           DEFAULT NULL,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_face_data_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_face_data_student (student_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- attendance_images : the raw + processed classroom photo per lecture
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance_images (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    lecture_id          INT             NOT NULL,
    image_path          VARCHAR(255)    NOT NULL,
    processed_image_path VARCHAR(255)   DEFAULT NULL,
    detected_faces      INT             DEFAULT 0,
    recognized_count    INT             DEFAULT 0,
    unknown_count       INT             DEFAULT 0,
    low_confidence_count INT            DEFAULT 0,
    uploaded_by         INT             NOT NULL COMMENT 'user_id of teacher/admin',
    uploaded_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_att_images_lecture FOREIGN KEY (lecture_id) REFERENCES lectures(id) ON DELETE CASCADE,
    INDEX idx_att_images_lecture (lecture_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- system_settings : admin-editable config (e.g. similarity threshold)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS system_settings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    setting_key     VARCHAR(100)    NOT NULL UNIQUE,
    setting_value   VARCHAR(255)    NOT NULL,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO system_settings (setting_key, setting_value)
VALUES ('face_similarity_threshold', '0.45')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

INSERT INTO system_settings (setting_key, setting_value)
VALUES ('default_absent_if_not_detected', 'false')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- ---------------------------------------------------------------------
-- login_logs : audit trail of authentication attempts
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_logs (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    email           VARCHAR(150)    NOT NULL,
    success         TINYINT(1)      NOT NULL,
    ip_address      VARCHAR(64),
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Seed a default admin account
-- password = Admin@123  (hashed with werkzeug pbkdf2:sha256 at app boot;
-- see database/db.py seed_default_admin() which creates this safely
-- through the ORM instead of a raw hash pasted here)
-- ---------------------------------------------------------------------
