"""
models/teacher.py
Academic profile for a teacher, linked one-to-one with a `users` row.
"""

from datetime import datetime

from database.db import db


class Teacher(db.Model):
    __tablename__ = "teachers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    employee_id = db.Column(db.String(50), nullable=False, unique=True, index=True)
    department = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    lectures = db.relationship("Lecture", backref="teacher", cascade="all, delete-orphan")

    def to_dict(self, include_user=True):
        data = {
            "id": self.id,
            "user_id": self.user_id,
            "employee_id": self.employee_id,
            "department": self.department,
        }
        if include_user and self.user:
            data["full_name"] = self.user.full_name
            data["email"] = self.user.email
        return data

    def __repr__(self):
        return f"<Teacher {self.employee_id}>"
