"""
models/subject.py
A course/subject offered within a department and semester.
"""

from datetime import datetime

from database.db import db


class Subject(db.Model):
    __tablename__ = "subjects"

    id = db.Column(db.Integer, primary_key=True)
    subject_name = db.Column(db.String(150), nullable=False)
    subject_code = db.Column(db.String(30), nullable=False, unique=True, index=True)
    semester = db.Column(db.Integer, nullable=False)
    department = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    lectures = db.relationship("Lecture", backref="subject", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "subject_name": self.subject_name,
            "subject_code": self.subject_code,
            "semester": self.semester,
            "department": self.department,
        }

    def __repr__(self):
        return f"<Subject {self.subject_code}>"
