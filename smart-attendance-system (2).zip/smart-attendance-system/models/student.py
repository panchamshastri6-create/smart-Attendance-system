"""
models/student.py
Academic profile for a student, linked one-to-one with a `users` row.
"""

from datetime import datetime

from database.db import db


class Student(db.Model):
    __tablename__ = "students"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    enrollment_number = db.Column(db.String(50), nullable=False, unique=True, index=True)
    department = db.Column(db.String(100), nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    division = db.Column(db.String(10), nullable=False)
    phone_number = db.Column(db.String(20))
    profile_image = db.Column(db.String(255))
    face_registered = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    face_images = db.relationship("FaceData", backref="student", cascade="all, delete-orphan")
    attendance_records = db.relationship("Attendance", backref="student", cascade="all, delete-orphan")

    def to_dict(self, include_user=True):
        data = {
            "id": self.id,
            "user_id": self.user_id,
            "enrollment_number": self.enrollment_number,
            "department": self.department,
            "semester": self.semester,
            "division": self.division,
            "phone_number": self.phone_number,
            "profile_image": self.profile_image,
            "face_registered": self.face_registered,
        }
        if include_user and self.user:
            data["full_name"] = self.user.full_name
            data["email"] = self.user.email
        return data

    def __repr__(self):
        return f"<Student {self.enrollment_number}>"
