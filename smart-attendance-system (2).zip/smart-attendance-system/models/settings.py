"""
models/settings.py
Admin-editable runtime settings (e.g. face similarity threshold) and a
simple authentication audit log.
"""

from datetime import datetime

from database.db import db


class SystemSetting(db.Model):
    __tablename__ = "system_settings"

    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), nullable=False, unique=True)
    setting_value = db.Column(db.String(255), nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    @staticmethod
    def get_value(key, default=None):
        row = SystemSetting.query.filter_by(setting_key=key).first()
        return row.setting_value if row else default

    @staticmethod
    def set_value(key, value):
        row = SystemSetting.query.filter_by(setting_key=key).first()
        if row:
            row.setting_value = str(value)
        else:
            row = SystemSetting(setting_key=key, setting_value=str(value))
            db.session.add(row)
        db.session.commit()
        return row

    def __repr__(self):
        return f"<SystemSetting {self.setting_key}={self.setting_value}>"


class LoginLog(db.Model):
    __tablename__ = "login_logs"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), nullable=False)
    success = db.Column(db.Boolean, nullable=False)
    ip_address = db.Column(db.String(64))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f"<LoginLog {self.email} success={self.success}>"
