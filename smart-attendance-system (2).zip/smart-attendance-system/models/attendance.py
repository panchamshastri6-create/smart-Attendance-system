"""
models/attendance.py
Core attendance records, per-student face embeddings, and the classroom
photos captured for each lecture.
"""

from datetime import datetime

from database.db import db


class Attendance(db.Model):
    __tablename__ = "attendance"

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id", ondelete="CASCADE"), nullable=False)
    lecture_id = db.Column(db.Integer, db.ForeignKey("lectures.id", ondelete="CASCADE"), nullable=False)
    status = db.Column(
        db.Enum("Present", "Absent", "Manual Present", "Pending", name="attendance_status"),
        default="Pending",
        nullable=False,
    )
    confidence_score = db.Column(db.Float, nullable=True)
    detection_method = db.Column(db.Enum("AI", "Manual", name="detection_method"), default="AI", nullable=False)
    marked_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    marked_by = db.Column(db.Integer, nullable=True)

    __table_args__ = (db.UniqueConstraint("student_id", "lecture_id", name="uniq_student_lecture"),)

    def to_dict(self):
        return {
            "id": self.id,
            "student_id": self.student_id,
            "enrollment_number": self.student.enrollment_number if self.student else None,
            "student_name": self.student.user.full_name if self.student and self.student.user else None,
            "lecture_id": self.lecture_id,
            "status": self.status,
            "confidence_score": round(self.confidence_score, 4) if self.confidence_score is not None else None,
            "detection_method": self.detection_method,
            "marked_at": self.marked_at.isoformat() if self.marked_at else None,
        }

    def __repr__(self):
        return f"<Attendance student={self.student_id} lecture={self.lecture_id} status={self.status}>"


class FaceData(db.Model):
    __tablename__ = "face_data"

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id", ondelete="CASCADE"), nullable=False)
    image_path = db.Column(db.String(255), nullable=False)
    embedding_path = db.Column(db.String(255), nullable=False)
    quality_score = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "student_id": self.student_id,
            "image_path": self.image_path,
            "embedding_path": self.embedding_path,
            "quality_score": self.quality_score,
        }

    def __repr__(self):
        return f"<FaceData student={self.student_id} img={self.image_path}>"


class AttendanceImage(db.Model):
    __tablename__ = "attendance_images"

    id = db.Column(db.Integer, primary_key=True)
    lecture_id = db.Column(db.Integer, db.ForeignKey("lectures.id", ondelete="CASCADE"), nullable=False)
    image_path = db.Column(db.String(255), nullable=False)
    processed_image_path = db.Column(db.String(255), nullable=True)
    detected_faces = db.Column(db.Integer, default=0)
    recognized_count = db.Column(db.Integer, default=0)
    unknown_count = db.Column(db.Integer, default=0)
    low_confidence_count = db.Column(db.Integer, default=0)
    uploaded_by = db.Column(db.Integer, nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "lecture_id": self.lecture_id,
            "image_path": self.image_path,
            "processed_image_path": self.processed_image_path,
            "detected_faces": self.detected_faces,
            "recognized_count": self.recognized_count,
            "unknown_count": self.unknown_count,
            "low_confidence_count": self.low_confidence_count,
            "uploaded_at": self.uploaded_at.isoformat() if self.uploaded_at else None,
        }

    def __repr__(self):
        return f"<AttendanceImage lecture={self.lecture_id}>"
