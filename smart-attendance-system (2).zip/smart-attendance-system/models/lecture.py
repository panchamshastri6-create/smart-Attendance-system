"""
models/lecture.py
Classroom (physical room) and Lecture (a scheduled class session) models.
"""

from datetime import datetime

from database.db import db


class Classroom(db.Model):
    __tablename__ = "classrooms"

    id = db.Column(db.Integer, primary_key=True)
    room_name = db.Column(db.String(100), nullable=False)
    building_name = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    lectures = db.relationship("Lecture", backref="classroom", cascade="all, delete-orphan")

    __table_args__ = (db.UniqueConstraint("room_name", "building_name", name="uniq_room_building"),)

    def to_dict(self):
        return {
            "id": self.id,
            "room_name": self.room_name,
            "building_name": self.building_name,
            "capacity": self.capacity,
        }

    def __repr__(self):
        return f"<Classroom {self.building_name}-{self.room_name}>"


class Lecture(db.Model):
    __tablename__ = "lectures"

    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False)
    classroom_id = db.Column(db.Integer, db.ForeignKey("classrooms.id", ondelete="CASCADE"), nullable=False)
    lecture_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    division = db.Column(db.String(10), nullable=False)
    status = db.Column(
        db.Enum("scheduled", "completed", "cancelled", name="lecture_status"),
        default="scheduled",
        nullable=False,
    )
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    attendance_records = db.relationship("Attendance", backref="lecture", cascade="all, delete-orphan")
    images = db.relationship("AttendanceImage", backref="lecture", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "subject_id": self.subject_id,
            "subject_name": self.subject.subject_name if self.subject else None,
            "subject_code": self.subject.subject_code if self.subject else None,
            "teacher_id": self.teacher_id,
            "teacher_name": self.teacher.user.full_name if self.teacher and self.teacher.user else None,
            "classroom_id": self.classroom_id,
            "classroom_name": (
                f"{self.classroom.building_name} - {self.classroom.room_name}" if self.classroom else None
            ),
            "lecture_date": self.lecture_date.isoformat() if self.lecture_date else None,
            "start_time": self.start_time.strftime("%H:%M") if self.start_time else None,
            "end_time": self.end_time.strftime("%H:%M") if self.end_time else None,
            "semester": self.semester,
            "division": self.division,
            "status": self.status,
        }

    def __repr__(self):
        return f"<Lecture {self.id} on {self.lecture_date}>"
