"""
models package
Re-exports every ORM model so `from models import User, Student, ...` works.
"""

from models.user import User
from models.student import Student
from models.teacher import Teacher
from models.subject import Subject
from models.lecture import Classroom, Lecture
from models.attendance import Attendance, FaceData, AttendanceImage
from models.settings import SystemSetting, LoginLog

__all__ = [
    "User",
    "Student",
    "Teacher",
    "Subject",
    "Classroom",
    "Lecture",
    "Attendance",
    "FaceData",
    "AttendanceImage",
    "SystemSetting",
    "LoginLog",
]
