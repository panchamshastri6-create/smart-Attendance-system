# AI Smart Attendance Management System

A complete, working, face-recognition-based attendance system for a university —
built for Smart India Hackathon. Teachers take one classroom photo; the system
detects every face, matches it against enrolled students using a pre-trained
InsightFace (ArcFace) model, and marks attendance automatically. Teachers review
and correct the result before confirming.

---

## 1. Project Overview

Traditional roll-call attendance is slow and easy to fake. This system replaces
it with a single classroom photo:

1. Students register once — academic profile + 10–20 face images.
2. The AI engine converts each photo into a 512-dimension face embedding
   (ArcFace, via InsightFace's pre-trained `buffalo_l` model pack).
3. A teacher schedules a lecture and, during class, uploads or captures one
   group photo.
4. The AI engine detects every face in the photo, compares each one against
   every enrolled student's embedding using cosine similarity, and marks
   recognized students **Present** automatically.
5. The teacher reviews the AI's decisions — confirms, corrects, or manually
   adds/removes any student — before the attendance is finalized.
6. Admins get dashboards, department/subject-wise analytics, and CSV/Excel/PDF
   exports.

No face-recognition model is trained from scratch — that would need a huge
labeled dataset and GPU resources this project doesn't assume you have. Instead,
we use InsightFace's pre-trained detection + recognition models and do the
"learning" via nearest-neighbor cosine similarity against each student's stored
embeddings, which is both accurate and instantly updatable (register a new
student and they're recognizable immediately — no retraining/redeployment).

---

## 2. Features

- Role-based system: **Admin**, **Teacher**, **Student**, each with a tailored dashboard
- Full student CRUD (add/edit/delete/search) + face registration (webcam or file upload)
- Image quality gates before accepting a registration photo: blur detection,
  exactly-one-face enforcement, minimum face size
- Lecture scheduling with classroom double-booking prevention
- One-photo attendance: detect → recognize → annotate → review → confirm
- Configurable face-similarity threshold (live, from the admin Settings page —
  no redeploy needed)
- Duplicate-attendance prevention enforced both in application logic and at
  the database level (`UNIQUE(student_id, lecture_id)`)
- Manual attendance correction: mark present/absent, remove a wrong AI
  detection, add a missed student
- Admin dashboard with Chart.js: daily trend, department-wise attendance
- Filterable reports (student / subject / department / semester / division /
  date range) with CSV, Excel, and PDF export
- Full audit logging to `logs/app.log` (logins, AI processing, errors)
- CSRF protection on every HTML form; session-based auth with hashed passwords

---

## 3. Technology Stack

**Frontend:** HTML5, CSS3 (custom design system), vanilla JavaScript, Bootstrap 5, Chart.js, Font Awesome

**Backend:** Python 3.11+, Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF, Flask-CORS

**Database:** MySQL 8 (via PyMySQL)

**AI / Computer Vision:** OpenCV, InsightFace (ArcFace recognition + RetinaFace
detection, `buffalo_l` model pack), ONNX Runtime, NumPy, scikit-learn

**Reporting:** pandas, openpyxl, ReportLab

**Deployment:** Gunicorn, Procfile (Render/Railway-ready)

---

## 4. Project Structure

```
smart-attendance-system/
├── app.py                     # Flask application factory / entry point
├── config.py                  # Environment-driven configuration
├── extensions.py              # Shared Flask extensions (CSRF)
├── requirements.txt
├── .env.example
├── Procfile / runtime.txt     # Deployment
├── database/
│   ├── schema.sql             # Full MySQL schema (run this once)
│   └── db.py                  # SQLAlchemy init + default-admin seeding
├── models/                    # SQLAlchemy ORM models (one per table)
├── routes/                    # Flask blueprints (HTML pages + JSON API)
├── services/                  # Business logic (DB + AI orchestration)
├── ai_engine/                 # Face detection / embedding / recognition
│   ├── config.py
│   ├── face_detector.py
│   ├── face_encoder.py
│   ├── face_recognizer.py
│   ├── embedding_manager.py
│   └── attendance_processor.py
├── utils/                     # Validators, image utils, RBAC decorators
├── templates/                 # Jinja2 HTML templates
├── static/{css,js,images}/
├── uploads/{students,classroom,processed}/
├── embeddings/                 # Persisted face embeddings (.npy per student)
├── logs/app.log
└── tests/                     # Pytest suite (38 tests)
```

---

## 5. Installation

### 5.1 Prerequisites
- Python 3.11 or 3.12
- MySQL Server 8.x
- A webcam (for live face capture — optional, file upload always works)

### 5.2 Clone and set up a virtual environment

**Windows (PowerShell):**
```powershell
git clone <your-repo-url>
cd smart-attendance-system

python -m venv venv
venv\Scripts\activate

pip install -r requirements.txt
```
> If PowerShell blocks the activation script with an "execution policy" error, run
> `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` once in that same
> window, then retry `venv\Scripts\activate`.

**macOS / Linux:**
```bash
git clone <your-repo-url>
cd smart-attendance-system

python -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

> **Note on InsightFace/ONNX Runtime:** the first time the app runs, InsightFace
> downloads its `buffalo_l` model pack (~300 MB) automatically to
> `~/.insightface/models/`. This requires an internet connection on first run
> only — after that it's cached locally.

### 5.3 MySQL database setup

**Windows (PowerShell):**
```powershell
mysql -u root -p < database\schema.sql
```
If your `mysql` client is not on PATH, either add
`C:\Program Files\MySQL\MySQL Server 8.0\bin` to PATH, or run the equivalent
from inside the MySQL client / MySQL Workbench by opening and executing
`database/schema.sql` directly.

**macOS / Linux:**
```bash
mysql -u root -p < database/schema.sql
```

This creates the `smart_attendance_db` database and every table. If you'd
rather let SQLAlchemy create the tables itself, you can skip this step — the
app calls `db.create_all()` on boot and will create anything missing (the
`.sql` file is provided so you can also inspect / hand-run the schema, and so
DBAs can review it independently of the ORM).

### 5.4 Environment variables

```bash
cp .env.example .env
```

Edit `.env` and set at minimum:

```
SECRET_KEY=<a long random string>
DB_HOST=localhost
DB_PORT=3306
DB_NAME=smart_attendance_db
DB_USER=root
DB_PASSWORD=<your MySQL password>
```

### 5.5 Run the app

**Windows (PowerShell):**
```powershell
python app.py
```

**macOS / Linux:**
```bash
python app.py
```

Visit **http://localhost:5000**. On first boot, a default admin account is
seeded automatically:

```
Email:    admin@university.edu   (or DEFAULT_ADMIN_EMAIL from .env)
Password: Admin@123               (or DEFAULT_ADMIN_PASSWORD from .env)
```

**Change this password immediately in any real deployment.**

---

## 6. How Face Registration Works

1. Admin (or the student) opens **Students → [student] → Face Registration**.
2. Capture 10–20 images via webcam (front, left, right, chin up, chin down) or
   upload existing photos.
3. Each image is validated **before** being accepted:
   - **Blur check** — variance-of-Laplacian sharpness score must clear a
     threshold ("Image is too blurry. Please retake in better lighting.")
   - **Face count check** — must contain exactly one face ("No face detected…"
     / "Please upload an image containing only one face.")
   - **Face size check** — the face must be large enough in the frame
4. Accepted images are saved to `uploads/students/`, and a 512-d ArcFace
   embedding is generated and saved to `embeddings/<student_id>/`.
5. Once at least `MIN_FACE_IMAGES_REQUIRED` (default 5) images are accepted,
   the student is marked `face_registered = true` and their **centroid
   embedding** (the average of all their accepted images' embeddings) becomes
   the reference used during classroom recognition.
6. `POST /api/face/train` rebuilds the in-memory recognition index from
   everything on disk — call this after bulk-registering many students at
   once (registering one student at a time already invalidates/rebuilds the
   cache automatically).

## 7. How Attendance Detection Works

1. Teacher selects a scheduled lecture and clicks **Take Attendance**.
2. Uploads a classroom group photo (or captures one via camera).
3. The photo is sent to `POST /api/attendance/process`, which:
   - Downscales very large images (configurable `MAX_CLASSROOM_IMAGE_DIMENSION`)
     for speed, without hurting accuracy
   - Detects every face (RetinaFace, via InsightFace)
   - Generates an embedding per face
   - Compares each embedding against every enrolled student's centroid via
     **cosine similarity**
   - Accepts the best match if its score clears `FACE_SIMILARITY_THRESHOLD`
     (default `0.45`, tunable live from **Settings**)
   - If two detected faces both match the same student, only the
     higher-confidence one is kept — the other is treated as unknown, so a
     student can never be marked present twice from one photo
   - Draws colour-coded boxes on the photo: **green** = recognized,
     **amber** = low-confidence (needs teacher review), **red** = unknown
4. Enrolled students not detected are set to **Pending** (default) or
   **Absent** (if the admin has enabled "auto-absent" in Settings).
5. The teacher reviews the annotated photo + roster, can manually correct any
   row, then clicks **Confirm Attendance** to finalize.

---

## 8. API Documentation

All JSON endpoints return `{"success": true/false, ...}` and standard HTTP
status codes (`200`/`201` success, `400` validation error, `401` unauthenticated,
`403` forbidden, `404` not found, `422` AI-rejected input, `500` server error).

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/login` | Log in, returns user + redirect URL |
| POST | `/api/auth/logout` | Log out |
| POST | `/api/auth/register` | Admin-only: create a user of any role |
| GET | `/api/auth/me` | Current user info |
| GET/POST | `/api/students` | List (paginated, filterable) / create a student |
| GET/PUT/DELETE | `/api/students/<id>` | Read / update / delete a student |
| GET | `/api/students/<id>/attendance-summary` | Overall + subject-wise % |
| GET/POST | `/api/teachers` | List / create teachers |
| DELETE | `/api/teachers/<id>` | Delete a teacher |
| GET/POST | `/api/subjects` | List / create subjects |
| DELETE | `/api/subjects/<id>` | Delete a subject |
| GET/POST | `/api/classrooms` | List / create classrooms |
| GET/POST | `/api/lectures` | List (filterable) / schedule a lecture |
| GET | `/api/lectures/<id>` | Lecture detail |
| POST | `/api/face/register` | Validate + store one face image (multipart file **or** base64 `image_data`) |
| GET | `/api/face/progress/<student_id>` | Registration progress |
| DELETE | `/api/face/<face_data_id>` | Remove one registered face image |
| POST | `/api/face/train` | Rebuild the in-memory recognition index |
| POST | `/api/face/process` | Standalone detect+recognize test (no DB writes) |
| POST | `/api/attendance/process` | Run AI on a classroom photo, stage attendance |
| GET | `/api/attendance/lecture/<id>` | Full roster + status for a lecture |
| POST | `/api/attendance/manual` | Manually set one student's status |
| POST | `/api/attendance/remove-detection` | Flag an AI detection as wrong → Absent |
| POST | `/api/attendance/confirm` | Finalize a lecture's attendance |
| GET | `/api/reports` | Filterable lecture-wise records |
| GET | `/api/reports/student-percentage` | Per-student attendance % |
| GET | `/api/reports/subject-wise` | Per-subject attendance % |
| GET | `/api/reports/export?format=csv\|excel\|pdf` | Download a report file |
| GET/POST | `/api/settings` | Read/update the similarity threshold + auto-absent flag |

---

## 9. Testing

A 38-test Pytest suite is included, covering authentication, student CRUD,
face-registration validation (blur / no-face / multi-face / success),
duplicate-attendance prevention, manual correction, role-based access control,
and report export.

```bash
pip install pytest
pytest tests/ -v
```

The heavy InsightFace/ONNX inference call is mocked at the lowest layer
(`ai_engine.face_detector.get_face_analysis_app`) so the suite runs in
seconds, fully offline, without downloading model weights. Every surrounding
layer — Flask routes, SQLAlchemy models and constraints, the recognition
math (cosine similarity, thresholding, duplicate-match resolution), embedding
persistence, and report generation — is exercised for real, nothing about the
business logic itself is mocked.

Manually verified test scenarios (also exercised in `tests/`):

1. Student registration (create/duplicate-rejection/update/delete/search)
2. Face registration (blurry image rejected, no-face rejected, multiple-faces
   rejected, valid single face accepted)
3. Classroom-photo processing end-to-end
4. Unknown-face rejection (cosine similarity below threshold)
5. Duplicate-attendance prevention (DB `UNIQUE` constraint + upsert logic)
6. Manual attendance correction
7. Database storage / relational integrity (cascading deletes, FKs)
8. Login authentication (correct/incorrect credentials, session handling)
9. Role-based access control (admin/teacher/student boundaries)

---

## 10. Deployment

### Render / Railway
Both platforms detect `Procfile` and `requirements.txt` automatically:

```
web: gunicorn app:app --workers 2 --timeout 120
```

Set the same environment variables from `.env.example` in the platform's
dashboard, and provision a MySQL add-on (or point `DB_HOST` at an external
MySQL instance).

### PythonAnywhere
Upload the project, create a virtualenv, `pip install -r requirements.txt`,
configure a MySQL database from their dashboard, set environment variables in
the WSGI config file, and point the web app at `app:app`.

### VPS / Linux server
```bash
pip install -r requirements.txt gunicorn
gunicorn app:app --workers 3 --bind 0.0.0.0:8000 --timeout 120
```
Put Nginx in front for TLS termination and static file serving.

> **Important limitation:** InsightFace + ONNX Runtime + OpenCV are heavy
> dependencies (~500 MB combined with model weights). Some free-tier hosts
> (e.g. free Render/Railway tiers) have build-size or memory limits that may
> not accommodate this. A VPS with at least 1–2 GB RAM, or a paid tier on
> Render/Railway, is recommended for reliable demo/production use.

---

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| `ModuleNotFoundError: insightface` | `pip install -r requirements.txt` inside the activated venv |
| InsightFace hangs/fails on first run | Needs internet access once to download `buffalo_l` model weights (~300 MB) to `~/.insightface/models/` |
| `sqlalchemy.exc.OperationalError: Can't connect to MySQL` | Confirm MySQL is running and `.env` DB credentials are correct |
| "No face detected in the uploaded image" during registration | Use a clear, well-lit, front-facing photo with only one person |
| Classroom photo shows many "Unknown" faces | Lower `FACE_SIMILARITY_THRESHOLD` slightly in **Settings**, or ensure those students completed face registration |
| CSRF token errors on a form | Make sure you're submitting the actual rendered form (with its hidden `csrf_token` field), not a hand-crafted request |
| Slow processing on large classroom photos | Reduce `MAX_CLASSROOM_IMAGE_DIMENSION` in `.env` |

---

## License / Attribution

Built for Smart India Hackathon. Uses the open-source InsightFace project
(`buffalo_l` model pack) for face detection and recognition — no proprietary
or paid face-recognition API is used.
