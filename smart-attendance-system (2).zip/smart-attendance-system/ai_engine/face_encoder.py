"""
ai_engine/face_encoder.py

Generates ArcFace face embeddings (512-dimensional vectors) for face
images. InsightFace's `FaceAnalysis.get()` pipeline already produces the
embedding as part of detection (it runs the RetinaFace detector and the
ArcFace recognition model together for efficiency), so this module reuses
the shared, singleton model instance from `face_detector.py` rather than
loading a second copy of the recognition network.
"""

import logging

import numpy as np

from ai_engine.face_detector import (
    FaceDetector,
    MultipleFacesDetectedError,
    NoFaceDetectedError,
)

logger = logging.getLogger("smart_attendance.ai_engine")


class FaceEncoder:
    """Produces normalized face embeddings suitable for cosine-similarity
    comparison."""

    def __init__(self, detector: FaceDetector = None):
        self.detector = detector or FaceDetector()

    def encode_single_face_image(self, image: np.ndarray) -> np.ndarray:
        """Given an image that should contain exactly one face (typical for
        a student registration photo), return its 512-d L2-normalized
        embedding.

        Raises NoFaceDetectedError / MultipleFacesDetectedError as needed.
        """
        face = self.detector.detect_single_face(image)
        return self.normalize_embedding(face.embedding)

    def encode_all_faces(self, image: np.ndarray):
        """Return a list of (DetectedFace, normalized_embedding) tuples for
        every face found in `image` (typical for a classroom group photo)."""
        faces = self.detector.detect_faces(image)
        return [(face, self.normalize_embedding(face.embedding)) for face in faces]

    @staticmethod
    def normalize_embedding(embedding: np.ndarray) -> np.ndarray:
        """L2-normalize an embedding vector so cosine similarity reduces to
        a plain dot product."""
        vec = np.asarray(embedding, dtype=np.float32).flatten()
        norm = np.linalg.norm(vec)
        if norm == 0:
            raise ValueError("Cannot normalize a zero-length embedding vector.")
        return vec / norm

    @staticmethod
    def average_embeddings(embeddings) -> np.ndarray:
        """Combine several normalized embeddings of the same person (e.g.
        the 10-20 registration photos) into a single robust centroid
        embedding, re-normalized to unit length."""
        if not embeddings:
            raise ValueError("Cannot average an empty list of embeddings.")
        stacked = np.vstack([np.asarray(e, dtype=np.float32).flatten() for e in embeddings])
        centroid = stacked.mean(axis=0)
        norm = np.linalg.norm(centroid)
        if norm == 0:
            raise ValueError("Averaged embedding has zero norm.")
        return centroid / norm


__all__ = ["FaceEncoder", "NoFaceDetectedError", "MultipleFacesDetectedError"]
