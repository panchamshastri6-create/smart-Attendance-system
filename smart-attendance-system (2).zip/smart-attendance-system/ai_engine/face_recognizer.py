"""
ai_engine/face_recognizer.py

Compares an unknown face embedding (from a classroom photo) against every
registered student's centroid embedding using cosine similarity, and
decides whether it is a confident match, a low-confidence match, or an
unknown face — using a configurable similarity threshold.
"""

import logging

import numpy as np

from ai_engine import config as ai_config
from ai_engine.embedding_manager import get_recognition_cache

logger = logging.getLogger("smart_attendance.ai_engine")


class RecognitionResult:
    """Outcome of comparing one detected face against all known students."""

    __slots__ = ("student_id", "name", "enrollment_number", "confidence", "status")

    def __init__(self, student_id, name, enrollment_number, confidence, status):
        self.student_id = student_id
        self.name = name
        self.enrollment_number = enrollment_number
        self.confidence = confidence
        self.status = status  # "recognized" | "low_confidence" | "unknown"

    def to_dict(self):
        return {
            "student_id": self.student_id,
            "name": self.name,
            "enrollment_number": self.enrollment_number,
            "confidence": round(float(self.confidence), 4) if self.confidence is not None else None,
            "status": self.status,
        }


def cosine_similarity(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
    """Cosine similarity between two vectors. Assumes both may or may not
    already be L2-normalized, so it normalizes defensively."""
    a = np.asarray(vec_a, dtype=np.float32).flatten()
    b = np.asarray(vec_b, dtype=np.float32).flatten()
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


class FaceRecognizer:
    """Matches unknown embeddings against the enrolled-student cache."""

    def __init__(self, similarity_threshold: float = None, low_confidence_margin: float = None,
                 db_session=None, student_model=None):
        self.similarity_threshold = (
            similarity_threshold if similarity_threshold is not None else ai_config.DEFAULT_SIMILARITY_THRESHOLD
        )
        self.low_confidence_margin = (
            low_confidence_margin if low_confidence_margin is not None else ai_config.LOW_CONFIDENCE_MARGIN
        )
        self.db_session = db_session
        self.student_model = student_model

    def _cache(self):
        return get_recognition_cache(db_session=self.db_session, student_model=self.student_model)

    def identify(self, embedding: np.ndarray) -> RecognitionResult:
        """Compare a single embedding against every enrolled student and
        return the best match classification."""
        cache = self._cache()
        if not cache:
            return RecognitionResult(None, None, None, 0.0, "unknown")

        best_student_id, best_score = None, -1.0
        for student_id, record in cache.items():
            score = cosine_similarity(embedding, record["embedding"])
            if score > best_score:
                best_score, best_student_id = score, student_id

        if best_student_id is None or best_score < self.similarity_threshold:
            return RecognitionResult(None, None, None, best_score, "unknown")

        record = cache[best_student_id]
        status = "recognized"
        if best_score < (self.similarity_threshold + self.low_confidence_margin):
            status = "low_confidence"

        return RecognitionResult(
            student_id=best_student_id,
            name=record["name"],
            enrollment_number=record["enrollment_number"],
            confidence=best_score,
            status=status,
        )

    def identify_batch(self, embeddings):
        """Identify a batch of embeddings (one per detected face in a
        classroom photo) and resolve duplicate matches: if two faces are
        both matched to the same student, only the higher-confidence match
        is kept as 'recognized' — the other is downgraded to 'unknown' so
        the same student can never be marked present twice from one photo.
        """
        results = [self.identify(e) for e in embeddings]

        best_index_per_student = {}
        for idx, result in enumerate(results):
            if result.student_id is None:
                continue
            current_best = best_index_per_student.get(result.student_id)
            if current_best is None or result.confidence > results[current_best].confidence:
                best_index_per_student[result.student_id] = idx

        keep_indices = set(best_index_per_student.values())
        for idx, result in enumerate(results):
            if result.student_id is not None and idx not in keep_indices:
                # Duplicate detection of an already-matched student: demote.
                results[idx] = RecognitionResult(
                    None, None, None, result.confidence, "duplicate"
                )

        return results
