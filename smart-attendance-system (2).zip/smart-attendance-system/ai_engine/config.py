"""
ai_engine/config.py
Runtime configuration for the face-recognition pipeline. Values are read
from the Flask app config when available (via `configure_from_app`), and
fall back to sane defaults so the AI engine can also be unit-tested
without a running Flask app.
"""

import os

# --- InsightFace model settings -----------------------------------------
INSIGHTFACE_MODEL_NAME = os.environ.get("INSIGHTFACE_MODEL_NAME", "buffalo_l")
INSIGHTFACE_PROVIDERS = os.environ.get("INSIGHTFACE_PROVIDERS", "CPUExecutionProvider").split(",")
DETECTION_SIZE = (640, 640)

# --- Recognition thresholds ----------------------------------------------
# Cosine similarity in [-1, 1]. Two embeddings of the same person from
# InsightFace's ArcFace model typically score above ~0.45-0.55.
DEFAULT_SIMILARITY_THRESHOLD = float(
    os.environ.get("FACE_MATCH_THRESHOLD", os.environ.get("FACE_SIMILARITY_THRESHOLD", "0.45"))
)
# If the gap between the best match and the threshold is smaller than this,
# the match is flagged "low confidence" instead of a clean accept.
LOW_CONFIDENCE_MARGIN = float(os.environ.get("LOW_CONFIDENCE_MARGIN", "0.05"))

# --- Registration quality gates -------------------------------------------
MIN_FACE_IMAGES_REQUIRED = int(os.environ.get("MIN_FACE_IMAGES_REQUIRED", "5"))
MAX_FACE_IMAGES_ALLOWED = int(os.environ.get("MAX_FACE_IMAGES_ALLOWED", "20"))
MIN_FACE_PIXEL_SIZE = 60          # reject faces smaller than 60x60 px in the source image
BLUR_LAPLACIAN_THRESHOLD = 60.0   # below this variance-of-Laplacian, image is considered blurry

# --- Classroom photo processing -------------------------------------------
MAX_CLASSROOM_IMAGE_DIMENSION = int(os.environ.get("MAX_CLASSROOM_IMAGE_DIMENSION", "1920"))

# --- Storage paths (overridden by configure_from_app in production) -------
EMBEDDING_FOLDER = os.environ.get("EMBEDDING_FOLDER", "embeddings")
STUDENT_IMAGE_FOLDER = os.path.join("uploads", "students")
CLASSROOM_IMAGE_FOLDER = os.path.join("uploads", "classroom")
PROCESSED_IMAGE_FOLDER = os.path.join("uploads", "processed")


def configure_from_app(app):
    """Pull runtime values from the live Flask app config so the AI engine
    and the web app always agree on thresholds and folders."""
    global DEFAULT_SIMILARITY_THRESHOLD, LOW_CONFIDENCE_MARGIN, MIN_FACE_IMAGES_REQUIRED
    global MAX_FACE_IMAGES_ALLOWED, MAX_CLASSROOM_IMAGE_DIMENSION
    global EMBEDDING_FOLDER, STUDENT_IMAGE_FOLDER, CLASSROOM_IMAGE_FOLDER, PROCESSED_IMAGE_FOLDER
    global INSIGHTFACE_MODEL_NAME, INSIGHTFACE_PROVIDERS

    DEFAULT_SIMILARITY_THRESHOLD = float(app.config.get("FACE_SIMILARITY_THRESHOLD", DEFAULT_SIMILARITY_THRESHOLD))
    LOW_CONFIDENCE_MARGIN = float(app.config.get("LOW_CONFIDENCE_MARGIN", LOW_CONFIDENCE_MARGIN))
    MIN_FACE_IMAGES_REQUIRED = int(app.config.get("MIN_FACE_IMAGES_REQUIRED", MIN_FACE_IMAGES_REQUIRED))
    MAX_FACE_IMAGES_ALLOWED = int(app.config.get("MAX_FACE_IMAGES_ALLOWED", MAX_FACE_IMAGES_ALLOWED))
    MAX_CLASSROOM_IMAGE_DIMENSION = int(
        app.config.get("MAX_CLASSROOM_IMAGE_DIMENSION", MAX_CLASSROOM_IMAGE_DIMENSION)
    )
    EMBEDDING_FOLDER = app.config.get("EMBEDDING_FOLDER", EMBEDDING_FOLDER)
    STUDENT_IMAGE_FOLDER = app.config.get("STUDENT_IMAGE_FOLDER", STUDENT_IMAGE_FOLDER)
    CLASSROOM_IMAGE_FOLDER = app.config.get("CLASSROOM_IMAGE_FOLDER", CLASSROOM_IMAGE_FOLDER)
    PROCESSED_IMAGE_FOLDER = app.config.get("PROCESSED_IMAGE_FOLDER", PROCESSED_IMAGE_FOLDER)
    INSIGHTFACE_MODEL_NAME = app.config.get("INSIGHTFACE_MODEL_NAME", INSIGHTFACE_MODEL_NAME)
    INSIGHTFACE_PROVIDERS = app.config.get("INSIGHTFACE_PROVIDERS", INSIGHTFACE_PROVIDERS)

    os.makedirs(EMBEDDING_FOLDER, exist_ok=True)
    os.makedirs(STUDENT_IMAGE_FOLDER, exist_ok=True)
    os.makedirs(CLASSROOM_IMAGE_FOLDER, exist_ok=True)
    os.makedirs(PROCESSED_IMAGE_FOLDER, exist_ok=True)
