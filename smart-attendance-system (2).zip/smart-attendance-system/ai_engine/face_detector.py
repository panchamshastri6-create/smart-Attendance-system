"""
ai_engine/face_detector.py

Wraps InsightFace's `FaceAnalysis` pipeline (RetinaFace detector +
5-point landmark predictor, from the pre-trained `buffalo_l` model pack)
to detect every face in an image and return bounding boxes, landmarks
and detection confidence.

The heavy ONNX models are loaded exactly ONCE per process via a module
level singleton (`get_face_analysis_app`), because loading them per
request would make classroom-photo processing far too slow.
"""

import logging
import threading

import cv2
import numpy as np

from ai_engine import config as ai_config

logger = logging.getLogger("smart_attendance.ai_engine")

_app_lock = threading.Lock()
_face_analysis_app = None  # module-level singleton, populated on first use


class DetectedFace:
    """Plain container for one detected face and everything derived from it."""

    __slots__ = ("bbox", "landmarks", "det_score", "embedding", "normed_embedding")

    def __init__(self, bbox, landmarks, det_score, embedding, normed_embedding):
        self.bbox = np.asarray(bbox, dtype=np.float32)          # [x1, y1, x2, y2]
        self.landmarks = np.asarray(landmarks, dtype=np.float32)  # 5 x 2 keypoints
        self.det_score = float(det_score)
        self.embedding = embedding                # raw 512-d ArcFace embedding
        self.normed_embedding = normed_embedding   # L2-normalized 512-d embedding

    @property
    def width(self):
        return float(self.bbox[2] - self.bbox[0])

    @property
    def height(self):
        return float(self.bbox[3] - self.bbox[1])

    @property
    def area(self):
        return max(0.0, self.width) * max(0.0, self.height)

    def to_dict(self):
        return {
            "bbox": [round(float(v), 2) for v in self.bbox.tolist()],
            "det_score": round(self.det_score, 4),
            "width": round(self.width, 1),
            "height": round(self.height, 1),
        }


def get_face_analysis_app():
    """Return the process-wide InsightFace FaceAnalysis instance, creating
    (and downloading model weights for, on first run) it if necessary."""
    global _face_analysis_app

    if _face_analysis_app is not None:
        return _face_analysis_app

    with _app_lock:
        if _face_analysis_app is not None:
            return _face_analysis_app

        # Imported lazily so the rest of the app can boot even in
        # environments (unit tests, static analysis) where the heavy
        # `insightface`/`onnxruntime` packages are not desired at import time.
        from insightface.app import FaceAnalysis

        logger.info(
            "Loading InsightFace model '%s' with providers %s ...",
            ai_config.INSIGHTFACE_MODEL_NAME,
            ai_config.INSIGHTFACE_PROVIDERS,
        )
        app = FaceAnalysis(
            name=ai_config.INSIGHTFACE_MODEL_NAME,
            providers=ai_config.INSIGHTFACE_PROVIDERS,
        )
        # ctx_id=-1 forces CPU-only execution graph selection; use 0 when a
        # CUDAExecutionProvider is configured for GPU inference.
        ctx_id = 0 if "CUDAExecutionProvider" in ai_config.INSIGHTFACE_PROVIDERS else -1
        app.prepare(ctx_id=ctx_id, det_size=ai_config.DETECTION_SIZE)
        _face_analysis_app = app
        logger.info("InsightFace model loaded successfully.")
        return _face_analysis_app


class FaceDetector:
    """Detects faces (and, as a side effect of InsightFace's pipeline,
    their ArcFace embeddings) in BGR images loaded via OpenCV."""

    def __init__(self):
        self.app = get_face_analysis_app()

    def detect_faces(self, image: np.ndarray):
        """Detect every face in `image` (BGR numpy array).

        Returns a list of DetectedFace objects, sorted by detection score
        descending. Returns an empty list if no face is found.
        """
        if image is None or image.size == 0:
            raise ValueError("Cannot run face detection on an empty image.")

        raw_faces = self.app.get(image)
        faces = [
            DetectedFace(
                bbox=f.bbox,
                landmarks=f.kps,
                det_score=f.det_score,
                embedding=f.embedding,
                normed_embedding=f.normed_embedding,
            )
            for f in raw_faces
        ]
        faces.sort(key=lambda f: f.det_score, reverse=True)
        return faces

    def detect_single_face(self, image: np.ndarray):
        """Convenience helper for registration flows: expects exactly one
        face in the image and raises a descriptive error otherwise."""
        faces = self.detect_faces(image)
        if len(faces) == 0:
            raise NoFaceDetectedError("No face detected in the uploaded image.")
        if len(faces) > 1:
            raise MultipleFacesDetectedError(
                "Please upload an image containing only one face."
            )
        return faces[0]

    @staticmethod
    def draw_faces(image: np.ndarray, boxes_with_labels):
        """Draw bounding boxes + labels on a copy of `image`.

        `boxes_with_labels` is a list of (bbox, label, color_bgr) tuples.
        Returns the annotated image (does not mutate the input).
        """
        annotated = image.copy()
        for bbox, label, color in boxes_with_labels:
            x1, y1, x2, y2 = [int(v) for v in bbox]
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            text_size, _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
            text_w, text_h = text_size
            label_y = max(y1 - 8, text_h + 4)
            cv2.rectangle(
                annotated,
                (x1, label_y - text_h - 6),
                (x1 + text_w + 6, label_y + 2),
                color,
                -1,
            )
            cv2.putText(
                annotated,
                label,
                (x1 + 3, label_y - 3),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )
        return annotated


class NoFaceDetectedError(Exception):
    """Raised when zero faces are found in an image that requires one."""


class MultipleFacesDetectedError(Exception):
    """Raised when more than one face is found where exactly one is expected."""
