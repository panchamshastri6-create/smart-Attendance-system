"""
ai_engine/attendance_processor.py

Top-level orchestration for the classroom-attendance AI pipeline:

    classroom photo -> detect every face -> generate embeddings
    -> compare against enrolled students -> classify each face as
    recognized / low-confidence / unknown -> draw annotated boxes
    -> return a structured result the Flask layer can persist to the DB.

This module does NOT touch the database directly — it is pure
image-in / structured-data-out so it can be unit tested in isolation.
`services/attendance_service.py` is responsible for turning its output
into `Attendance` rows.
"""

import logging
import os
import time
import uuid

import cv2

from ai_engine import config as ai_config
from ai_engine.face_detector import FaceDetector
from ai_engine.face_encoder import FaceEncoder
from ai_engine.face_recognizer import FaceRecognizer

logger = logging.getLogger("smart_attendance.ai_engine")

# BGR colors (OpenCV convention) for the three confidence tiers.
COLOR_RECOGNIZED = (86, 156, 27)      # green
COLOR_LOW_CONFIDENCE = (11, 170, 234)  # amber/yellow
COLOR_UNKNOWN = (52, 52, 197)          # red


class AttendanceProcessor:
    """Runs the full detect -> encode -> recognize -> annotate pipeline on
    a single classroom photo."""

    def __init__(self, similarity_threshold: float = None, db_session=None, student_model=None):
        self.detector = FaceDetector()
        self.encoder = FaceEncoder(detector=self.detector)
        self.recognizer = FaceRecognizer(
            similarity_threshold=similarity_threshold,
            db_session=db_session,
            student_model=student_model,
        )

    @staticmethod
    def _resize_if_needed(image):
        """Downscale very large classroom photos (e.g. 4000x3000 phone
        camera shots) so detection stays fast, while preserving aspect
        ratio. Returns (possibly resized image, scale_factor)."""
        h, w = image.shape[:2]
        max_dim = ai_config.MAX_CLASSROOM_IMAGE_DIMENSION
        longest_side = max(h, w)
        if longest_side <= max_dim:
            return image, 1.0
        scale = max_dim / float(longest_side)
        resized = cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
        return resized, scale

    def process(self, image_path: str, lecture_id: int) -> dict:
        """Process one classroom photo end-to-end.

        Returns a dict with:
          detected_faces, recognized (list), low_confidence (list),
          unknown (list), processed_image_path, processing_time_ms
        """
        start = time.time()

        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not read image at path: {image_path}")

        working_image, scale = self._resize_if_needed(image)

        faces_with_embeddings = self.encoder.encode_all_faces(working_image)
        detected_count = len(faces_with_embeddings)

        recognized, low_confidence, unknown = [], [], []
        annotations = []

        if detected_count > 0:
            embeddings = [emb for _face, emb in faces_with_embeddings]
            results = self.recognizer.identify_batch(embeddings)

            for (face, _embedding), result in zip(faces_with_embeddings, results):
                # Map bbox back to the ORIGINAL (un-resized) image coordinates.
                bbox_original = (face.bbox / scale).tolist()
                entry = {
                    "bbox": [round(v, 1) for v in bbox_original],
                    "det_score": round(face.det_score, 4),
                    **result.to_dict(),
                }

                if result.status == "recognized":
                    recognized.append(entry)
                    label = f"{result.name} ({result.confidence:.2f})"
                    annotations.append((bbox_original, label, COLOR_RECOGNIZED))
                elif result.status == "low_confidence":
                    low_confidence.append(entry)
                    label = f"{result.name}? ({result.confidence:.2f})"
                    annotations.append((bbox_original, label, COLOR_LOW_CONFIDENCE))
                else:
                    # "unknown" or "duplicate" (second detection of an
                    # already-matched student) both render as unknown so a
                    # face can never silently double-count.
                    unknown.append(entry)
                    label = "Unknown"
                    annotations.append((bbox_original, label, COLOR_UNKNOWN))

        processed_image = FaceDetector.draw_faces(image, annotations)
        processed_filename = f"lecture{lecture_id}_{uuid.uuid4().hex[:10]}.jpg"
        processed_path = os.path.join(ai_config.PROCESSED_IMAGE_FOLDER, processed_filename)
        os.makedirs(ai_config.PROCESSED_IMAGE_FOLDER, exist_ok=True)
        cv2.imwrite(processed_path, processed_image, [int(cv2.IMWRITE_JPEG_QUALITY), 90])

        elapsed_ms = round((time.time() - start) * 1000, 1)
        logger.info(
            "Processed classroom image for lecture %s: %d faces detected "
            "(%d recognized, %d low-confidence, %d unknown) in %.1f ms",
            lecture_id, detected_count, len(recognized), len(low_confidence), len(unknown), elapsed_ms,
        )

        return {
            "detected_faces": detected_count,
            "recognized": recognized,
            "low_confidence": low_confidence,
            "unknown": unknown,
            "processed_image_path": processed_path,
            "processing_time_ms": elapsed_ms,
        }
