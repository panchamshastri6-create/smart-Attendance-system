"""
ai_engine/embedding_manager.py

Handles persistence of face embeddings to disk (as .npy files under
EMBEDDING_FOLDER/<student_id>/) and maintains an in-memory, process-wide
cache of "one centroid embedding per student" so that recognizing faces
in a classroom photo does not have to hit the database or the filesystem
for every comparison.

Cache invalidation: any write (register/delete) bumps a version counter
and clears the cache; the next recognition call rebuilds it lazily.
"""

import logging
import os
import threading

import numpy as np

from ai_engine import config as ai_config

logger = logging.getLogger("smart_attendance.ai_engine")

_cache_lock = threading.Lock()
_embedding_cache = {}       # student_id -> {"embedding": np.ndarray, "name":..., "enrollment_number":...}
_cache_built = False


def _student_embedding_dir(student_id: int) -> str:
    path = os.path.join(ai_config.EMBEDDING_FOLDER, str(student_id))
    os.makedirs(path, exist_ok=True)
    return path


def save_embedding(student_id: int, embedding: np.ndarray, image_filename: str) -> str:
    """Persist a single face embedding to disk and return its file path."""
    folder = _student_embedding_dir(student_id)
    base_name = os.path.splitext(os.path.basename(image_filename))[0]
    file_path = os.path.join(folder, f"{base_name}.npy")
    np.save(file_path, np.asarray(embedding, dtype=np.float32))
    invalidate_cache()
    return file_path


def load_embedding(embedding_path: str) -> np.ndarray:
    if not os.path.exists(embedding_path):
        raise FileNotFoundError(f"Embedding file not found: {embedding_path}")
    return np.load(embedding_path)


def load_student_embeddings(student_id: int):
    """Load every stored embedding vector for a single student."""
    folder = _student_embedding_dir(student_id)
    vectors = []
    for fname in sorted(os.listdir(folder)):
        if fname.endswith(".npy"):
            vectors.append(np.load(os.path.join(folder, fname)))
    return vectors


def delete_student_embeddings(student_id: int):
    """Remove all stored embeddings for a student (e.g. on re-registration
    or account deletion)."""
    folder = _student_embedding_dir(student_id)
    if os.path.isdir(folder):
        for fname in os.listdir(folder):
            os.remove(os.path.join(folder, fname))
    invalidate_cache()


def invalidate_cache():
    global _cache_built
    with _cache_lock:
        _embedding_cache.clear()
        _cache_built = False


def build_recognition_cache(db_session=None, student_model=None):
    """Build (or rebuild) the in-memory student_id -> centroid embedding
    cache used for fast recognition. Requires the SQLAlchemy session and
    Student model to pull enrolled students; pass None/None to instead
    rebuild purely from what's on disk (embeddings dir has one folder per
    student id, but names/enrollment numbers then default to placeholders).
    """
    global _cache_built

    with _cache_lock:
        _embedding_cache.clear()

        if not os.path.isdir(ai_config.EMBEDDING_FOLDER):
            _cache_built = True
            return _embedding_cache

        for entry in os.listdir(ai_config.EMBEDDING_FOLDER):
            student_folder = os.path.join(ai_config.EMBEDDING_FOLDER, entry)
            if not os.path.isdir(student_folder) or not entry.isdigit():
                continue

            student_id = int(entry)
            vectors = [
                np.load(os.path.join(student_folder, f))
                for f in sorted(os.listdir(student_folder))
                if f.endswith(".npy")
            ]
            if not vectors:
                continue

            stacked = np.vstack([v.flatten() for v in vectors])
            centroid = stacked.mean(axis=0)
            norm = np.linalg.norm(centroid)
            if norm == 0:
                continue
            centroid = centroid / norm

            name, enrollment_number = f"Student {student_id}", str(student_id)
            if db_session is not None and student_model is not None:
                student = db_session.get(student_model, student_id)
                if student is not None:
                    enrollment_number = student.enrollment_number
                    name = student.user.full_name if student.user else name

            _embedding_cache[student_id] = {
                "embedding": centroid,
                "name": name,
                "enrollment_number": enrollment_number,
            }

        _cache_built = True
        logger.info("Recognition cache rebuilt: %d students loaded.", len(_embedding_cache))
        return _embedding_cache


def get_recognition_cache(db_session=None, student_model=None):
    """Return the cached {student_id: {...}} dict, building it on first
    access or after an invalidation."""
    if not _cache_built:
        return build_recognition_cache(db_session=db_session, student_model=student_model)
    return _embedding_cache
