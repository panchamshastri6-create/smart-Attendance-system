"""
ai_engine package
Face detection, embedding, recognition and attendance-image processing.
"""

from ai_engine.face_detector import FaceDetector, NoFaceDetectedError, MultipleFacesDetectedError
from ai_engine.face_encoder import FaceEncoder
from ai_engine.face_recognizer import FaceRecognizer, cosine_similarity
from ai_engine.attendance_processor import AttendanceProcessor

__all__ = [
    "FaceDetector",
    "FaceEncoder",
    "FaceRecognizer",
    "AttendanceProcessor",
    "NoFaceDetectedError",
    "MultipleFacesDetectedError",
    "cosine_similarity",
]
