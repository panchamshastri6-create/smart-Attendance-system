"""
utils/decorators.py
Role-based access-control decorators built on top of Flask-Login.
"""

from functools import wraps

from flask import abort, jsonify, redirect, request, url_for
from flask_login import current_user


def roles_required(*roles):
    """Restrict a view to users whose `.role` is in `roles`. Unauthenticated
    users are redirected to login (HTML) or get a 401 (JSON API)."""

    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                if request.path.startswith("/api/"):
                    return jsonify({"success": False, "message": "Authentication required."}), 401
                return redirect(url_for("auth.login", next=request.path))

            if current_user.role not in roles:
                if request.path.startswith("/api/"):
                    return jsonify({"success": False, "message": "You do not have permission to do that."}), 403
                abort(403)

            return view_func(*args, **kwargs)

        return wrapped

    return decorator


def admin_required(view_func):
    return roles_required("admin")(view_func)


def teacher_required(view_func):
    return roles_required("teacher", "admin")(view_func)


def student_required(view_func):
    return roles_required("student", "admin")(view_func)
