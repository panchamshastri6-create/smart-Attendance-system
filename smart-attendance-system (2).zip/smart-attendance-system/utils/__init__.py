"""utils package: shared helpers for validation, images, and access control."""
