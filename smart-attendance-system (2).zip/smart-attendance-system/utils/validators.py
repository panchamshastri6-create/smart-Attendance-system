"""
utils/validators.py
Reusable validation helpers for form and JSON API input.
"""

import re

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_REGEX = re.compile(r"^[0-9+\-\s]{7,15}$")
ENROLLMENT_REGEX = re.compile(r"^[A-Za-z0-9\-/]{3,50}$")


class ValidationError(Exception):
    """Raised by validators; carries a user-facing message."""


def require_fields(data: dict, fields: list):
    missing = [f for f in fields if not str(data.get(f, "")).strip()]
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(missing)}")


def validate_email(email: str) -> str:
    email = (email or "").strip().lower()
    if not EMAIL_REGEX.match(email):
        raise ValidationError("Please provide a valid email address.")
    return email


def validate_password_strength(password: str) -> str:
    if not password or len(password) < 6:
        raise ValidationError("Password must be at least 6 characters long.")
    return password


def validate_phone(phone: str) -> str:
    phone = (phone or "").strip()
    if phone and not PHONE_REGEX.match(phone):
        raise ValidationError("Please provide a valid phone number.")
    return phone


def validate_enrollment_number(value: str) -> str:
    value = (value or "").strip().upper()
    if not ENROLLMENT_REGEX.match(value):
        raise ValidationError("Enrollment number must be 3-50 alphanumeric characters.")
    return value


def validate_semester(value) -> int:
    try:
        sem = int(value)
    except (TypeError, ValueError):
        raise ValidationError("Semester must be a number.")
    if sem < 1 or sem > 12:
        raise ValidationError("Semester must be between 1 and 12.")
    return sem


def validate_role(role: str) -> str:
    role = (role or "").strip().lower()
    if role not in ("admin", "teacher", "student"):
        raise ValidationError("Role must be one of: admin, teacher, student.")
    return role


def validate_status(status: str) -> str:
    status = (status or "").strip()
    valid = {"Present", "Absent", "Manual Present", "Pending"}
    if status not in valid:
        raise ValidationError(f"Status must be one of: {', '.join(sorted(valid))}.")
    return status
