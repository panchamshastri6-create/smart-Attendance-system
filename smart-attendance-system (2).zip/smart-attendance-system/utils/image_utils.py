"""
utils/image_utils.py
Low-level image helpers shared across routes/services: file validation,
blur detection, quality scoring and safe filename generation.
"""

import os
import uuid

import cv2
import numpy as np
from werkzeug.utils import secure_filename


def allowed_image_file(filename: str, allowed_extensions: set) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in allowed_extensions


def generate_unique_filename(original_filename: str, prefix: str = "") -> str:
    ext = "jpg"
    if original_filename and "." in original_filename:
        ext = original_filename.rsplit(".", 1)[1].lower()
    safe_prefix = secure_filename(prefix) if prefix else ""
    unique_part = uuid.uuid4().hex[:16]
    if safe_prefix:
        return f"{safe_prefix}_{unique_part}.{ext}"
    return f"{unique_part}.{ext}"


def read_image_from_filestorage(file_storage) -> np.ndarray:
    """Decode a Flask/Werkzeug FileStorage upload into an OpenCV BGR image
    without ever writing the raw upload to disk first."""
    file_bytes = np.frombuffer(file_storage.read(), dtype=np.uint8)
    file_storage.seek(0)
    image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    return image


def compute_blur_score(image: np.ndarray) -> float:
    """Variance of the Laplacian — a standard, cheap sharpness metric.
    Lower values indicate a blurrier image."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def is_image_too_blurry(image: np.ndarray, threshold: float) -> bool:
    return compute_blur_score(image) < threshold


def resize_max_dimension(image: np.ndarray, max_dimension: int) -> np.ndarray:
    h, w = image.shape[:2]
    longest = max(h, w)
    if longest <= max_dimension:
        return image
    scale = max_dimension / float(longest)
    return cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def save_image(image: np.ndarray, folder: str, filename: str) -> str:
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    cv2.imwrite(path, image, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    return path
