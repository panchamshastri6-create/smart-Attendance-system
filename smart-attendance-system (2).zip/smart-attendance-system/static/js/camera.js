/**
 * static/js/camera.js
 * Drives the face-registration page: webcam capture (10-20 angled shots)
 * and/or bulk file upload, each image validated server-side (single face,
 * not blurry, adequate size) before being accepted.
 *
 * Expects these globals to be set by face_registration.html:
 *   window.STUDENT_ID, window.FACE_REGISTER_URL, window.MAX_IMAGES, window.REQUIRED_MIN
 */

(function () {
    "use strict";

    const video = document.getElementById("webcamVideo");
    const canvas = document.getElementById("captureCanvas");
    const startCameraBtn = document.getElementById("startCameraBtn");
    const captureBtn = document.getElementById("captureBtn");
    const fileInput = document.getElementById("fileUploadInput");
    const thumbGallery = document.getElementById("thumbGallery");
    const progressFill = document.getElementById("progressFill");
    const progressCount = document.getElementById("progressCount");
    const statusMessage = document.getElementById("statusMessage");

    let mediaStream = null;
    let capturedCount = 0;

    if (!video) return; // not on the face registration page

    startCameraBtn.addEventListener("click", async function () {
        try {
            mediaStream = await navigator.mediaDevices.getUserMedia({
                video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "user" },
            });
            video.srcObject = mediaStream;
            captureBtn.disabled = false;
            startCameraBtn.innerHTML = '<i class="fa-solid fa-video"></i> Camera Active';
            startCameraBtn.disabled = true;
        } catch (err) {
            showToast("Unable to access camera. Please check browser permissions.", "danger");
        }
    });

    captureBtn.addEventListener("click", function () {
        if (!mediaStream) return;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
        submitImage({ image_data: dataUrl }, false);
    });

    fileInput.addEventListener("change", function () {
        const files = Array.from(fileInput.files || []);
        files.forEach((file) => submitImage(file, true));
        fileInput.value = "";
    });

    async function submitImage(payload, isFile) {
        if (capturedCount >= window.MAX_IMAGES) {
            showToast(`Maximum of ${window.MAX_IMAGES} images already registered.`, "warning");
            return;
        }

        let response;
        try {
            if (isFile) {
                const formData = new FormData();
                formData.append("student_id", window.STUDENT_ID);
                formData.append("image", payload);
                response = await fetch(window.FACE_REGISTER_URL, { method: "POST", body: formData });
            } else {
                response = await fetch(window.FACE_REGISTER_URL, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ student_id: window.STUDENT_ID, image_data: payload.image_data }),
                });
            }
            const data = await response.json();
            handleRegisterResult(data, payload, isFile);
        } catch (err) {
            showToast("Network error while uploading the image.", "danger");
        }
    }

    function handleRegisterResult(data, payload, isFile) {
        if (data.success) {
            capturedCount = data.progress.captured;
            addThumbnail(isFile ? payload : payload.image_data, isFile);
            updateProgress(data.progress);
            showToast("Face image accepted.", "success");
        } else {
            showToast(data.message || "Image was rejected.", "danger");
        }
    }

    function addThumbnail(source, isFile) {
        const img = document.createElement("img");
        img.className = "capture-thumb";
        if (isFile) {
            const reader = new FileReader();
            reader.onload = (e) => { img.src = e.target.result; };
            reader.readAsDataURL(source);
        } else {
            img.src = source;
        }
        thumbGallery.appendChild(img);
    }

    function updateProgress(progress) {
        const pct = progress.required_minimum ? Math.min(100, (progress.captured / progress.required_minimum) * 100) : 0;
        progressFill.style.width = pct + "%";
        progressCount.textContent = `${progress.captured} / ${progress.required_minimum} minimum`;

        if (progress.is_complete) {
            statusMessage.innerHTML = '<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> Face registration completed successfully.';
        } else {
            statusMessage.textContent = `Capture at least ${progress.required_minimum} good images to complete registration.`;
        }
    }

    window.addEventListener("beforeunload", function () {
        if (mediaStream) {
            mediaStream.getTracks().forEach((track) => track.stop());
        }
    });
})();
