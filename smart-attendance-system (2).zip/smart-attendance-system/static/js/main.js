/**
 * static/js/main.js
 * Shared, page-agnostic utilities: a small toast/notification helper and
 * a fetch wrapper used across the app's other JS files.
 */

(function () {
    "use strict";

    function ensureToastContainer() {
        let container = document.getElementById("appToastContainer");
        if (!container) {
            container = document.createElement("div");
            container.id = "appToastContainer";
            container.style.position = "fixed";
            container.style.top = "20px";
            container.style.right = "20px";
            container.style.zIndex = "2000";
            container.style.display = "flex";
            container.style.flexDirection = "column";
            container.style.gap = "10px";
            document.body.appendChild(container);
        }
        return container;
    }

    /**
     * Show a small toast notification.
     * @param {string} message
     * @param {"success"|"danger"|"warning"|"info"} type
     */
    window.showToast = function (message, type) {
        type = type || "info";
        const colors = {
            success: { bg: "#e7f5ee", text: "#1f8a55" },
            danger: { bg: "#fbeae8", text: "#c0392b" },
            warning: { bg: "#fdf1de", text: "#b9770e" },
            info: { bg: "#e8eff9", text: "#2d5fa8" },
        };
        const palette = colors[type] || colors.info;

        const container = ensureToastContainer();
        const toast = document.createElement("div");
        toast.textContent = message;
        toast.style.background = palette.bg;
        toast.style.color = palette.text;
        toast.style.padding = "12px 18px";
        toast.style.borderRadius = "8px";
        toast.style.fontFamily = "'Manrope', sans-serif";
        toast.style.fontSize = "13.5px";
        toast.style.fontWeight = "600";
        toast.style.boxShadow = "0 4px 16px rgba(15,26,48,0.12)";
        toast.style.maxWidth = "340px";
        toast.style.opacity = "0";
        toast.style.transition = "opacity 0.2s ease";
        container.appendChild(toast);

        requestAnimationFrame(() => { toast.style.opacity = "1"; });
        setTimeout(() => {
            toast.style.opacity = "0";
            setTimeout(() => toast.remove(), 250);
        }, 3800);
    };

    /**
     * fetch() wrapper that always sends/receives JSON and throws with a
     * readable message on failure.
     */
    window.apiFetch = async function (url, options) {
        options = options || {};
        const opts = Object.assign({ headers: {} }, options);
        if (!(opts.body instanceof FormData)) {
            opts.headers["Content-Type"] = "application/json";
        }
        const response = await fetch(url, opts);
        let data;
        try {
            data = await response.json();
        } catch (e) {
            data = { success: false, message: "Unexpected server response." };
        }
        if (!response.ok && data.success === undefined) {
            data.success = false;
        }
        return data;
    };
})();
