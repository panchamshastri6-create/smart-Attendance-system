/**
 * static/js/attendance.js
 * Drives the "Take Attendance" page: lets the teacher upload a classroom
 * photo or capture one from the camera, previews it, then submits it to
 * the AI processing endpoint and redirects to the results page.
 *
 * Expects: window.LECTURE_ID, window.ATTENDANCE_PROCESS_URL, window.ATTENDANCE_RESULT_URL
 */

(function () {
    "use strict";

    const video = document.getElementById("attendanceVideo");
    const previewImage = document.getElementById("previewImage");
    const canvas = document.getElementById("attendanceCanvas");
    const framePlaceholder = document.getElementById("framePlaceholder");
    const fileInput = document.getElementById("classroomFileInput");
    const startCameraBtn = document.getElementById("startAttendanceCameraBtn");
    const captureBtn = document.getElementById("captureAttendanceBtn");
    const processBtn = document.getElementById("processAttendanceBtn");
    const processingStatus = document.getElementById("processingStatus");
    const processingMessage = document.getElementById("processingMessage");
    const processingError = document.getElementById("processingError");

    if (!processBtn) return; // not on the take-attendance page

    let mediaStream = null;
    let selectedBlob = null; // the final image blob that will be uploaded

    function showPreview(url) {
        framePlaceholder.style.display = "none";
        video.style.display = "none";
        previewImage.style.display = "block";
        previewImage.src = url;
        processBtn.disabled = false;
    }

    fileInput.addEventListener("change", function () {
        const file = fileInput.files[0];
        if (!file) return;
        stopCamera();
        selectedBlob = file;
        showPreview(URL.createObjectURL(file));
    });

    startCameraBtn.addEventListener("click", async function () {
        try {
            mediaStream = await navigator.mediaDevices.getUserMedia({
                video: { width: { ideal: 1280 }, height: { ideal: 720 } },
            });
            framePlaceholder.style.display = "none";
            previewImage.style.display = "none";
            video.style.display = "block";
            video.srcObject = mediaStream;
            captureBtn.style.display = "inline-flex";
            startCameraBtn.disabled = true;
        } catch (err) {
            showToast("Unable to access camera. Please check browser permissions.", "danger");
        }
    });

    captureBtn.addEventListener("click", function () {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
            selectedBlob = blob;
            showPreview(URL.createObjectURL(blob));
            stopCamera();
        }, "image/jpeg", 0.92);
    });

    function stopCamera() {
        if (mediaStream) {
            mediaStream.getTracks().forEach((track) => track.stop());
            mediaStream = null;
        }
        video.style.display = "none";
        captureBtn.style.display = "none";
        startCameraBtn.disabled = false;
        startCameraBtn.innerHTML = '<i class="fa-solid fa-video"></i> Open Camera';
    }

    processBtn.addEventListener("click", async function () {
        if (!selectedBlob) {
            showToast("Please select or capture a classroom photo first.", "warning");
            return;
        }

        processBtn.disabled = true;
        processingStatus.style.display = "block";
        processingError.style.display = "none";
        processingMessage.textContent = "AI is detecting faces...";

        const formData = new FormData();
        formData.append("lecture_id", window.LECTURE_ID);
        formData.append("image", selectedBlob, "classroom.jpg");

        try {
            const response = await fetch(window.ATTENDANCE_PROCESS_URL, { method: "POST", body: formData });
            const data = await response.json();

            if (data.success) {
                const r = data.result;
                processingMessage.textContent =
                    `Detected ${r.detected_faces} face(s): ${r.recognized.length} recognized, ` +
                    `${r.low_confidence.length} low-confidence, ${r.unknown.length} unknown. Redirecting...`;
                setTimeout(() => { window.location.href = window.ATTENDANCE_RESULT_URL; }, 900);
            } else {
                processingStatus.style.display = "none";
                processingError.style.display = "block";
                processingError.innerHTML = `<div class="alert-app alert-app-danger"><i class="fa-solid fa-circle-exclamation"></i> ${data.message}</div>`;
                processBtn.disabled = false;
            }
        } catch (err) {
            processingStatus.style.display = "none";
            processingError.style.display = "block";
            processingError.innerHTML = '<div class="alert-app alert-app-danger"><i class="fa-solid fa-circle-exclamation"></i> Network error while processing the image. Please try again.</div>';
            processBtn.disabled = false;
        }
    });

    window.addEventListener("beforeunload", stopCamera);
})();
