"""
config.py
Central application configuration, loaded from environment variables.
Never hard-code secrets here — everything sensitive comes from `.env`.
"""

import os
from datetime import timedelta

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


def _bool_env(name, default="false"):
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes", "on")


class Config:
    """Base configuration shared by every environment."""

    # --- Core Flask ---
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")
    JSON_SORT_KEYS = False

    # --- Database (MySQL via PyMySQL driver) ---
    DB_HOST = os.environ.get("DB_HOST", "localhost")
    DB_PORT = os.environ.get("DB_PORT", "3306")
    DB_NAME = os.environ.get("DB_NAME", "smart_attendance_db")
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 280,
    }

    # --- Uploads ---
    BASE_UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", os.path.join(BASE_DIR, "uploads"))
    STUDENT_IMAGE_FOLDER = os.path.join(BASE_UPLOAD_FOLDER, "students")
    CLASSROOM_IMAGE_FOLDER = os.path.join(BASE_UPLOAD_FOLDER, "classroom")
    PROCESSED_IMAGE_FOLDER = os.path.join(BASE_UPLOAD_FOLDER, "processed")
    EMBEDDING_FOLDER = os.environ.get("EMBEDDING_FOLDER", os.path.join(BASE_DIR, "embeddings"))

    ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_UPLOAD_MB", "20")) * 1024 * 1024  # 20 MB default

    # --- Face recognition / AI engine ---
    # FACE_MATCH_THRESHOLD is the canonical name; FACE_SIMILARITY_THRESHOLD is
    # kept as a fallback for backward compatibility with earlier .env files.
    FACE_SIMILARITY_THRESHOLD = float(
        os.environ.get("FACE_MATCH_THRESHOLD", os.environ.get("FACE_SIMILARITY_THRESHOLD", "0.45"))
    )
    FACE_MATCH_THRESHOLD = FACE_SIMILARITY_THRESHOLD
    FACE_DETECTION_SIZE = (640, 640)
    MIN_FACE_IMAGES_REQUIRED = int(os.environ.get("MIN_FACE_IMAGES_REQUIRED", "5"))
    MAX_FACE_IMAGES_ALLOWED = int(os.environ.get("MAX_FACE_IMAGES_ALLOWED", "20"))
    INSIGHTFACE_MODEL_NAME = os.environ.get("INSIGHTFACE_MODEL_NAME", "buffalo_l")
    INSIGHTFACE_PROVIDERS = os.environ.get("INSIGHTFACE_PROVIDERS", "CPUExecutionProvider").split(",")
    LOW_CONFIDENCE_MARGIN = float(os.environ.get("LOW_CONFIDENCE_MARGIN", "0.05"))
    MAX_CLASSROOM_IMAGE_DIMENSION = int(os.environ.get("MAX_CLASSROOM_IMAGE_DIMENSION", "1920"))

    # --- Session / auth ---
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"

    # --- Attendance rules ---
    DEFAULT_ABSENT_IF_NOT_DETECTED = _bool_env("DEFAULT_ABSENT_IF_NOT_DETECTED", "false")

    # --- CORS (for the JSON API only; set to a comma-separated origin list
    #     in production instead of "*") ---
    CORS_ALLOWED_ORIGINS = os.environ.get("CORS_ALLOWED_ORIGINS", "*")

    # --- Logging ---
    LOG_FOLDER = os.path.join(BASE_DIR, "logs")
    LOG_FILE = os.path.join(LOG_FOLDER, "app.log")


class DevelopmentConfig(Config):
    DEBUG = True
    SESSION_COOKIE_SECURE = False


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "TEST_DATABASE_URL", "sqlite:///" + os.path.join(BASE_DIR, "test.db")
    )
    WTF_CSRF_ENABLED = False


config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}


def get_config():
    env = os.environ.get("FLASK_ENV", "development")
    return config_by_name.get(env, DevelopmentConfig)
