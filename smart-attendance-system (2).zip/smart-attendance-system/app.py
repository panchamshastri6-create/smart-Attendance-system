"""
app.py
Application factory + entry point for the AI Smart Attendance Management
System. Run with:  python app.py
"""

import logging
import os
from logging.handlers import RotatingFileHandler

from flask import Flask, jsonify, render_template
from flask_cors import CORS
from flask_login import LoginManager

from ai_engine import config as ai_config
from config import get_config
from database.db import db, init_db
from extensions import csrf


def _configure_logging(app):
    os.makedirs(app.config["LOG_FOLDER"], exist_ok=True)
    log_format = logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    file_handler = RotatingFileHandler(app.config["LOG_FILE"], maxBytes=2_000_000, backupCount=5)
    file_handler.setFormatter(log_format)
    file_handler.setLevel(logging.INFO)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_format)
    console_handler.setLevel(logging.INFO)

    root_logger = logging.getLogger("smart_attendance")
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    werkzeug_logger = logging.getLogger("werkzeug")
    werkzeug_logger.addHandler(file_handler)


def _ensure_folders(app):
    for folder in (
        app.config["BASE_UPLOAD_FOLDER"],
        app.config["STUDENT_IMAGE_FOLDER"],
        app.config["CLASSROOM_IMAGE_FOLDER"],
        app.config["PROCESSED_IMAGE_FOLDER"],
        app.config["EMBEDDING_FOLDER"],
        app.config["LOG_FOLDER"],
    ):
        os.makedirs(folder, exist_ok=True)


def _register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(err):
        if _wants_json():
            return jsonify({"success": False, "message": "Bad request."}), 400
        return render_template("errors/400.html"), 400

    @app.errorhandler(403)
    def forbidden(err):
        if _wants_json():
            return jsonify({"success": False, "message": "Forbidden."}), 403
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(err):
        if _wants_json():
            return jsonify({"success": False, "message": "Resource not found."}), 404
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(err):
        logging.getLogger("smart_attendance").exception("Unhandled server error: %s", err)
        if _wants_json():
            return jsonify({"success": False, "message": "Internal server error."}), 500
        return render_template("errors/500.html"), 500


def _wants_json():
    from flask import request

    return request.path.startswith("/api/") or request.is_json


def create_app(config_object=None):
    app = Flask(__name__)
    app.config.from_object(config_object or get_config())

    _configure_logging(app)
    _ensure_folders(app)

    # --- Database -----------------------------------------------------
    init_db(app)

    # --- AI engine: bind runtime thresholds/folders to this app's config --
    ai_config.configure_from_app(app)

    # --- CORS: allow the JSON API to be called from a separate front-end
    #     origin (e.g. a future mobile app or a teacher's tablet PWA served
    #     from a different domain). HTML routes are unaffected.
    CORS(app, resources={r"/api/*": {"origins": app.config.get("CORS_ALLOWED_ORIGINS", "*")}}, supports_credentials=True)

    # --- CSRF protection for HTML forms (JSON /api/ routes call
    #     `@csrf.exempt` individually since they authenticate via the
    #     session cookie + are consumed by fetch(), not browser forms) ----
    csrf.init_app(app)

    # --- Login manager --------------------------------------------------
    login_manager = LoginManager()
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to access this page."
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        from models.user import User

        return User.query.get(int(user_id))

    # --- Blueprints -------------------------------------------------------
    from routes import register_blueprints

    register_blueprints(app)

    _register_error_handlers(app)

    @app.context_processor
    def inject_globals():
        import datetime

        return {"current_year": datetime.date.today().year, "app_name": "AI Smart Attendance System"}

    return app


app = create_app()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = app.config.get("DEBUG", True)
    app.run(host="0.0.0.0", port=port, debug=debug)
