"""
services/face_service.py
Handles the student face-registration workflow: validating uploaded/
webcam-captured images, running them through the AI engine, and
persisting both the source image and its embedding.
"""

import logging
import os

from ai_engine import config as ai_config
from ai_engine.embedding_manager import invalidate_cache, save_embedding
from ai_engine.face_detector import FaceDetector, MultipleFacesDetectedError, NoFaceDetectedError
from ai_engine.face_encoder import FaceEncoder
from database.db import db
from models.attendance import FaceData
from models.student import Student
from utils.image_utils import (
    compute_blur_score,
    generate_unique_filename,
    is_image_too_blurry,
    save_image,
)
from utils.validators import ValidationError

logger = logging.getLogger("smart_attendance.services")

# Module-level singletons: the detector/encoder load heavy ONNX models,
# so they are created once and reused for every registration image.
_detector = None
_encoder = None


def _get_encoder():
    global _detector, _encoder
    if _encoder is None:
        _detector = FaceDetector()
        _encoder = FaceEncoder(detector=_detector)
    return _encoder


class FaceImageResult:
    def __init__(self, accepted, message, face_data_id=None, quality_score=None):
        self.accepted = accepted
        self.message = message
        self.face_data_id = face_data_id
        self.quality_score = quality_score

    def to_dict(self):
        return {
            "accepted": self.accepted,
            "message": self.message,
            "face_data_id": self.face_data_id,
            "quality_score": self.quality_score,
        }


def register_face_image(student_id: int, image) -> FaceImageResult:
    """Validate and store ONE registration image for a student.

    `image` is an OpenCV BGR numpy array (already decoded by the route
    layer, e.g. from an uploaded file or a webcam capture data URL).
    """
    student = Student.query.get(student_id)
    if not student:
        raise ValidationError("Student not found.")

    encoder = _get_encoder()

    # --- 1. Blur / quality check -------------------------------------
    blur_score = compute_blur_score(image)
    if is_image_too_blurry(image, ai_config.BLUR_LAPLACIAN_THRESHOLD):
        return FaceImageResult(False, "Image is too blurry. Please retake in better lighting.", quality_score=blur_score)

    # --- 2. Face detection: exactly one face required ------------------
    try:
        face = encoder.detector.detect_single_face(image)
    except NoFaceDetectedError:
        return FaceImageResult(False, "No face detected in the uploaded image.")
    except MultipleFacesDetectedError:
        return FaceImageResult(False, "Please upload an image containing only one face.")

    # --- 3. Minimum face size in the frame ------------------------------
    if face.width < ai_config.MIN_FACE_PIXEL_SIZE or face.height < ai_config.MIN_FACE_PIXEL_SIZE:
        return FaceImageResult(False, "Face is too small in the frame. Please move closer to the camera.")

    # --- 4. Existing image count guard ---------------------------------
    existing_count = FaceData.query.filter_by(student_id=student_id).count()
    if existing_count >= ai_config.MAX_FACE_IMAGES_ALLOWED:
        return FaceImageResult(
            False, f"Maximum of {ai_config.MAX_FACE_IMAGES_ALLOWED} face images already registered."
        )

    # --- 5. Persist image + embedding -----------------------------------
    embedding = FaceEncoder.normalize_embedding(face.embedding)
    filename = generate_unique_filename("capture.jpg", prefix=f"student{student_id}")
    image_path = save_image(image, ai_config.STUDENT_IMAGE_FOLDER, filename)
    embedding_path = save_embedding(student_id, embedding, filename)

    face_data = FaceData(
        student_id=student_id,
        image_path=image_path,
        embedding_path=embedding_path,
        quality_score=blur_score,
    )
    db.session.add(face_data)

    new_count = existing_count + 1
    if new_count >= ai_config.MIN_FACE_IMAGES_REQUIRED:
        student.face_registered = True
        if not student.profile_image:
            student.profile_image = image_path

    db.session.commit()
    invalidate_cache()

    logger.info("Registered face image %d/%d for student %s", new_count, ai_config.MAX_FACE_IMAGES_ALLOWED, student_id)
    return FaceImageResult(True, "Face image accepted.", face_data_id=face_data.id, quality_score=blur_score)


def get_face_registration_progress(student_id: int) -> dict:
    count = FaceData.query.filter_by(student_id=student_id).count()
    return {
        "captured": count,
        "required_minimum": ai_config.MIN_FACE_IMAGES_REQUIRED,
        "maximum_allowed": ai_config.MAX_FACE_IMAGES_ALLOWED,
        "is_complete": count >= ai_config.MIN_FACE_IMAGES_REQUIRED,
    }


def delete_face_image(face_data_id: int):
    face_data = FaceData.query.get(face_data_id)
    if not face_data:
        raise ValidationError("Face image not found.")

    student_id = face_data.student_id
    for path in (face_data.image_path, face_data.embedding_path):
        if path and os.path.exists(path):
            os.remove(path)

    db.session.delete(face_data)

    remaining = FaceData.query.filter_by(student_id=student_id).count() - 1
    student = Student.query.get(student_id)
    if student and remaining < ai_config.MIN_FACE_IMAGES_REQUIRED:
        student.face_registered = False

    db.session.commit()
    invalidate_cache()
