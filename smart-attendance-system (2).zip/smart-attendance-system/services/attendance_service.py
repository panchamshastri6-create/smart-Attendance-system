"""
services/attendance_service.py
Ties the AI engine to the database: runs classroom-photo processing,
stages attendance rows, and exposes manual-correction operations. Every
write goes through `_upsert_attendance` so a student can NEVER receive two
attendance rows for the same lecture (enforced both here and by the DB's
UNIQUE(student_id, lecture_id) constraint).
"""

import logging
import os

from ai_engine.attendance_processor import AttendanceProcessor
from database.db import db
from models.attendance import Attendance, AttendanceImage
from models.lecture import Lecture
from models.student import Student
from utils.validators import ValidationError

logger = logging.getLogger("smart_attendance.services")


def _upsert_attendance(student_id, lecture_id, status, confidence_score, detection_method, marked_by=None):
    record = Attendance.query.filter_by(student_id=student_id, lecture_id=lecture_id).first()
    if record is None:
        record = Attendance(student_id=student_id, lecture_id=lecture_id)
        db.session.add(record)

    record.status = status
    record.confidence_score = confidence_score
    record.detection_method = detection_method
    if marked_by is not None:
        record.marked_by = marked_by
    return record


def process_classroom_photo(lecture_id: int, image_path: str, uploaded_by: int,
                             similarity_threshold: float = None) -> dict:
    """Run the AI pipeline on a freshly uploaded classroom photo and stage
    attendance for every recognized/low-confidence student. Call
    `finalize_absentees` afterwards to resolve everyone else."""
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")
    if lecture.status == "completed":
        raise ValidationError(
            "Attendance has already been recorded and confirmed for this lecture. "
            "Use Manual Attendance to make further corrections."
        )
    if not os.path.exists(image_path):
        raise ValidationError("Uploaded classroom image could not be found on disk.")

    processor = AttendanceProcessor(
        similarity_threshold=similarity_threshold,
        db_session=db.session,
        student_model=Student,
    )
    result = processor.process(image_path=image_path, lecture_id=lecture_id)

    attendance_image = AttendanceImage(
        lecture_id=lecture_id,
        image_path=image_path,
        processed_image_path=result["processed_image_path"],
        detected_faces=result["detected_faces"],
        recognized_count=len(result["recognized"]),
        unknown_count=len(result["unknown"]),
        low_confidence_count=len(result["low_confidence"]),
        uploaded_by=uploaded_by,
    )
    db.session.add(attendance_image)

    recognized_student_ids = set()
    for entry in result["recognized"]:
        _upsert_attendance(
            student_id=entry["student_id"],
            lecture_id=lecture_id,
            status="Present",
            confidence_score=entry["confidence"],
            detection_method="AI",
        )
        recognized_student_ids.add(entry["student_id"])

    for entry in result["low_confidence"]:
        # Low-confidence matches are staged as Pending so a teacher must
        # explicitly confirm them rather than silently marking present.
        _upsert_attendance(
            student_id=entry["student_id"],
            lecture_id=lecture_id,
            status="Pending",
            confidence_score=entry["confidence"],
            detection_method="AI",
        )
        recognized_student_ids.add(entry["student_id"])

    db.session.commit()

    result["lecture_id"] = lecture_id
    result["attendance_image_id"] = attendance_image.id
    result["recognized_student_ids"] = list(recognized_student_ids)
    return result


def finalize_absentees(lecture_id: int, recognized_student_ids, default_absent: bool):
    """After AI staging, give every ENROLLED student who was not detected a
    row: 'Absent' if the admin/teacher configured that default, otherwise
    'Pending' so the teacher must manually resolve them."""
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")

    enrolled = Student.query.filter_by(semester=lecture.semester, division=lecture.division).all()
    fallback_status = "Absent" if default_absent else "Pending"

    for student in enrolled:
        if student.id in recognized_student_ids:
            continue
        existing = Attendance.query.filter_by(student_id=student.id, lecture_id=lecture_id).first()
        if existing:
            continue  # don't overwrite a status a teacher may already have touched
        db.session.add(
            Attendance(
                student_id=student.id,
                lecture_id=lecture_id,
                status=fallback_status,
                confidence_score=None,
                detection_method="AI",
            )
        )
    db.session.commit()


def get_lecture_attendance(lecture_id: int):
    """Full roster (every enrolled student) merged with whatever attendance
    row exists for this lecture, for the review/results page."""
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")

    enrolled = (
        Student.query.filter_by(semester=lecture.semester, division=lecture.division)
        .order_by(Student.enrollment_number.asc())
        .all()
    )
    records = {a.student_id: a for a in Attendance.query.filter_by(lecture_id=lecture_id).all()}

    roster = []
    for student in enrolled:
        record = records.get(student.id)
        roster.append(
            {
                "student_id": student.id,
                "enrollment_number": student.enrollment_number,
                "full_name": student.user.full_name if student.user else "",
                "status": record.status if record else "Pending",
                "confidence_score": round(record.confidence_score, 4)
                if record and record.confidence_score is not None
                else None,
                "detection_method": record.detection_method if record else None,
                "attendance_id": record.id if record else None,
            }
        )
    return roster


def manual_mark_attendance(lecture_id: int, student_id: int, status: str, marked_by: int) -> Attendance:
    student = Student.query.get(student_id)
    if not student:
        raise ValidationError("Student not found.")
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")

    record = _upsert_attendance(
        student_id=student_id,
        lecture_id=lecture_id,
        status=status,
        confidence_score=None,
        detection_method="Manual",
        marked_by=marked_by,
    )
    db.session.commit()
    logger.info("Manual attendance: student=%s lecture=%s status=%s by=%s", student_id, lecture_id, status, marked_by)
    return record


def remove_incorrect_detection(attendance_id: int, marked_by: int) -> Attendance:
    """Teacher flags an AI detection as wrong -> demote to Absent, keep an
    audit trail via detection_method=Manual."""
    record = Attendance.query.get(attendance_id)
    if not record:
        raise ValidationError("Attendance record not found.")
    record.status = "Absent"
    record.detection_method = "Manual"
    record.confidence_score = None
    record.marked_by = marked_by
    db.session.commit()
    return record


def confirm_attendance(lecture_id: int, confirmed_by: int):
    """Finalize a lecture: mark it completed and stamp any still-unmarked
    (`marked_by is NULL`) rows with the confirming teacher."""
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")

    records = Attendance.query.filter_by(lecture_id=lecture_id).all()
    for record in records:
        if record.marked_by is None:
            record.marked_by = confirmed_by

    lecture.status = "completed"
    db.session.commit()
    logger.info("Lecture %s attendance confirmed by user=%s", lecture_id, confirmed_by)
    return lecture
