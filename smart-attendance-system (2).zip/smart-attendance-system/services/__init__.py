"""services package: business logic shared by HTML routes and JSON API routes."""
