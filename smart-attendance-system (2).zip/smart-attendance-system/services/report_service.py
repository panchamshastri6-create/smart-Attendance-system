"""
services/report_service.py
Aggregated attendance analytics for the admin dashboard and the reports
page: percentages, date-range filters, and CSV/Excel/PDF export payloads.
"""

import datetime
import io

import pandas as pd

from database.db import db
from models.attendance import Attendance
from models.lecture import Lecture
from models.student import Student
from models.subject import Subject
from models.teacher import Teacher
from models.user import User


def filtered_attendance_query(student_id=None, subject_id=None, department=None, semester=None,
                               division=None, date_from=None, date_to=None):
    q = (
        db.session.query(Attendance, Student, User, Lecture, Subject)
        .join(Student, Attendance.student_id == Student.id)
        .join(User, Student.user_id == User.id)
        .join(Lecture, Attendance.lecture_id == Lecture.id)
        .join(Subject, Lecture.subject_id == Subject.id)
    )
    if student_id:
        q = q.filter(Student.id == student_id)
    if subject_id:
        q = q.filter(Subject.id == subject_id)
    if department:
        q = q.filter(Student.department == department)
    if semester:
        q = q.filter(Student.semester == semester)
    if division:
        q = q.filter(Student.division == division)
    if date_from:
        q = q.filter(Lecture.lecture_date >= date_from)
    if date_to:
        q = q.filter(Lecture.lecture_date <= date_to)
    return q.order_by(Lecture.lecture_date.desc())


def build_report_rows(**filters):
    rows = []
    for attendance, student, user, lecture, subject in filtered_attendance_query(**filters).all():
        rows.append(
            {
                "date": lecture.lecture_date.isoformat(),
                "subject_code": subject.subject_code,
                "subject_name": subject.subject_name,
                "enrollment_number": student.enrollment_number,
                "student_name": user.full_name,
                "department": student.department,
                "semester": student.semester,
                "division": student.division,
                "status": attendance.status,
                "detection_method": attendance.detection_method,
                "confidence_score": attendance.confidence_score,
            }
        )
    return rows


def student_percentage_report(department=None, semester=None, division=None):
    """One row per student with overall attendance percentage — used for
    the 'Student attendance percentage' report."""
    q = Student.query.join(User)
    if department:
        q = q.filter(Student.department == department)
    if semester:
        q = q.filter(Student.semester == semester)
    if division:
        q = q.filter(Student.division == division)

    report = []
    for student in q.all():
        records = Attendance.query.filter_by(student_id=student.id).all()
        total = len(records)
        present = sum(1 for r in records if r.status in ("Present", "Manual Present"))
        percentage = round((present / total) * 100, 1) if total else 0.0
        report.append(
            {
                "enrollment_number": student.enrollment_number,
                "student_name": student.user.full_name,
                "department": student.department,
                "semester": student.semester,
                "division": student.division,
                "total_lectures": total,
                "present_count": present,
                "percentage": percentage,
            }
        )
    report.sort(key=lambda r: r["percentage"])
    return report


def subject_wise_report(subject_id=None):
    q = Lecture.query
    if subject_id:
        q = q.filter(Lecture.subject_id == subject_id)
    lectures = q.all()

    report = {}
    for lecture in lectures:
        subject = lecture.subject
        key = subject.subject_code if subject else "UNKNOWN"
        stats = report.setdefault(
            key, {"subject_name": subject.subject_name if subject else "Unknown", "total_marks": 0, "present": 0}
        )
        records = Attendance.query.filter_by(lecture_id=lecture.id).all()
        stats["total_marks"] += len(records)
        stats["present"] += sum(1 for r in records if r.status in ("Present", "Manual Present"))

    for stats in report.values():
        stats["percentage"] = (
            round((stats["present"] / stats["total_marks"]) * 100, 1) if stats["total_marks"] else 0.0
        )
    return report


def department_wise_attendance(date_from=None, date_to=None):
    q = (
        db.session.query(Student.department, Attendance.status)
        .join(Attendance, Attendance.student_id == Student.id)
        .join(Lecture, Attendance.lecture_id == Lecture.id)
    )
    if date_from:
        q = q.filter(Lecture.lecture_date >= date_from)
    if date_to:
        q = q.filter(Lecture.lecture_date <= date_to)

    totals = {}
    for department, status in q.all():
        stats = totals.setdefault(department, {"total": 0, "present": 0})
        stats["total"] += 1
        if status in ("Present", "Manual Present"):
            stats["present"] += 1

    for stats in totals.values():
        stats["percentage"] = round((stats["present"] / stats["total"]) * 100, 1) if stats["total"] else 0.0
    return totals


def daily_attendance_trend(days: int = 14):
    """Attendance percentage per calendar day for the last `days` days —
    feeds the admin dashboard's Chart.js line chart."""
    start_date = datetime.date.today() - datetime.timedelta(days=days - 1)
    q = (
        db.session.query(Lecture.lecture_date, Attendance.status)
        .join(Attendance, Attendance.lecture_id == Lecture.id)
        .filter(Lecture.lecture_date >= start_date)
    )

    by_day = {}
    for lecture_date, status in q.all():
        stats = by_day.setdefault(lecture_date, {"total": 0, "present": 0})
        stats["total"] += 1
        if status in ("Present", "Manual Present"):
            stats["present"] += 1

    labels, percentages = [], []
    for i in range(days):
        day = start_date + datetime.timedelta(days=i)
        stats = by_day.get(day, {"total": 0, "present": 0})
        pct = round((stats["present"] / stats["total"]) * 100, 1) if stats["total"] else 0.0
        labels.append(day.strftime("%d %b"))
        percentages.append(pct)
    return {"labels": labels, "percentages": percentages}


def export_to_csv(rows: list) -> io.BytesIO:
    df = pd.DataFrame(rows)
    buffer = io.BytesIO()
    df.to_csv(buffer, index=False)
    buffer.seek(0)
    return buffer


def export_to_excel(rows: list) -> io.BytesIO:
    df = pd.DataFrame(rows)
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Attendance Report")
    buffer.seek(0)
    return buffer


def export_to_pdf(rows: list, title: str = "Attendance Report") -> io.BytesIO:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import landscape, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(A4))
    styles = getSampleStyleSheet()
    elements = [Paragraph(title, styles["Title"]), Spacer(1, 12)]

    if rows:
        headers = list(rows[0].keys())
        data = [headers] + [[str(row.get(h, "")) for h in headers] for row in rows]
        table = Table(data, repeatRows=1)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1B2A4A")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 7),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F4F6F8")]),
                ]
            )
        )
        elements.append(table)
    else:
        elements.append(Paragraph("No records match the selected filters.", styles["Normal"]))

    doc.build(elements)
    buffer.seek(0)
    return buffer
