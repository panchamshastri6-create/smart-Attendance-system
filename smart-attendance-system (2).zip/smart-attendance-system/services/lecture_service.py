"""
services/lecture_service.py
Business logic for creating and querying lectures (class sessions).
"""

import datetime
import logging

from database.db import db
from models.lecture import Classroom, Lecture
from models.subject import Subject
from models.teacher import Teacher
from utils.validators import ValidationError, require_fields, validate_semester

logger = logging.getLogger("smart_attendance.services")


def create_lecture(data: dict) -> Lecture:
    require_fields(data, ["subject_id", "teacher_id", "classroom_id", "lecture_date", "start_time", "end_time"])

    subject = Subject.query.get(int(data["subject_id"]))
    if not subject:
        raise ValidationError("Selected subject does not exist.")
    teacher = Teacher.query.get(int(data["teacher_id"]))
    if not teacher:
        raise ValidationError("Selected teacher does not exist.")
    classroom = Classroom.query.get(int(data["classroom_id"]))
    if not classroom:
        raise ValidationError("Selected classroom does not exist.")

    try:
        lecture_date = datetime.datetime.strptime(data["lecture_date"], "%Y-%m-%d").date()
        start_time = datetime.datetime.strptime(data["start_time"], "%H:%M").time()
        end_time = datetime.datetime.strptime(data["end_time"], "%H:%M").time()
    except ValueError:
        raise ValidationError("Invalid date/time format. Use YYYY-MM-DD and HH:MM.")

    if end_time <= start_time:
        raise ValidationError("End time must be after start time.")

    semester = validate_semester(data.get("semester", subject.semester))
    division = (data.get("division") or "").strip().upper()
    if not division:
        raise ValidationError("Division is required.")

    # Prevent double-booking the same classroom in an overlapping slot.
    clashing = Lecture.query.filter(
        Lecture.classroom_id == classroom.id,
        Lecture.lecture_date == lecture_date,
        Lecture.status != "cancelled",
        Lecture.start_time < end_time,
        Lecture.end_time > start_time,
    ).first()
    if clashing:
        raise ValidationError("This classroom is already booked for an overlapping time slot.")

    lecture = Lecture(
        subject_id=subject.id,
        teacher_id=teacher.id,
        classroom_id=classroom.id,
        lecture_date=lecture_date,
        start_time=start_time,
        end_time=end_time,
        semester=semester,
        division=division,
    )
    db.session.add(lecture)
    db.session.commit()
    logger.info("Created lecture id=%s for subject=%s on %s", lecture.id, subject.subject_code, lecture_date)
    return lecture


def get_lectures(teacher_id=None, subject_id=None, date_from=None, date_to=None, page=1, per_page=20):
    q = Lecture.query
    if teacher_id:
        q = q.filter(Lecture.teacher_id == teacher_id)
    if subject_id:
        q = q.filter(Lecture.subject_id == subject_id)
    if date_from:
        q = q.filter(Lecture.lecture_date >= date_from)
    if date_to:
        q = q.filter(Lecture.lecture_date <= date_to)
    q = q.order_by(Lecture.lecture_date.desc(), Lecture.start_time.desc())
    return q.paginate(page=page, per_page=per_page, error_out=False)


def get_today_lectures(teacher_id=None):
    today = datetime.date.today()
    q = Lecture.query.filter(Lecture.lecture_date == today)
    if teacher_id:
        q = q.filter(Lecture.teacher_id == teacher_id)
    return q.order_by(Lecture.start_time.asc()).all()


def get_upcoming_lectures(teacher_id=None, limit=5):
    today = datetime.date.today()
    q = Lecture.query.filter(Lecture.lecture_date >= today, Lecture.status == "scheduled")
    if teacher_id:
        q = q.filter(Lecture.teacher_id == teacher_id)
    return q.order_by(Lecture.lecture_date.asc(), Lecture.start_time.asc()).limit(limit).all()


def mark_lecture_completed(lecture_id: int):
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        raise ValidationError("Lecture not found.")
    lecture.status = "completed"
    db.session.commit()
    return lecture
