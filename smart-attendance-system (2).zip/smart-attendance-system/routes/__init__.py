"""
routes package
Central place that wires every Blueprint onto the Flask app instance.
"""


def register_blueprints(app):
    from routes.auth_routes import auth_bp
    from routes.dashboard_routes import dashboard_bp
    from routes.student_routes import student_bp
    from routes.teacher_routes import teacher_bp
    from routes.subject_routes import subject_bp
    from routes.lecture_routes import lecture_bp
    from routes.attendance_routes import attendance_bp
    from routes.face_routes import face_bp
    from routes.report_routes import report_bp
    from routes.settings_routes import settings_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(teacher_bp)
    app.register_blueprint(subject_bp)
    app.register_blueprint(lecture_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(face_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(settings_bp)
