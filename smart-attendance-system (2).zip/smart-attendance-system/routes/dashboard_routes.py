"""
routes/dashboard_routes.py
Role-specific landing dashboards, each with the summary stats and charts
described in the project spec.
"""

import datetime

from flask import Blueprint, redirect, render_template, url_for
from flask_login import current_user, login_required

from models.attendance import Attendance
from models.lecture import Lecture
from models.student import Student
from models.subject import Subject
from models.teacher import Teacher
from services import lecture_service, report_service, student_service
from utils.decorators import admin_required, student_required, teacher_required

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@login_required
def index():
    return redirect(
        {
            "admin": url_for("dashboard.admin_dashboard"),
            "teacher": url_for("dashboard.teacher_dashboard"),
            "student": url_for("dashboard.student_dashboard"),
        }[current_user.role]
    )


@dashboard_bp.route("/dashboard/admin")
@admin_required
def admin_dashboard():
    today = datetime.date.today()
    total_students = Student.query.count()
    total_teachers = Teacher.query.count()
    total_subjects = Subject.query.count()
    todays_lectures = Lecture.query.filter(Lecture.lecture_date == today).count()

    todays_records = (
        Attendance.query.join(Lecture, Attendance.lecture_id == Lecture.id)
        .filter(Lecture.lecture_date == today)
        .all()
    )
    todays_total = len(todays_records)
    todays_present = sum(1 for r in todays_records if r.status in ("Present", "Manual Present"))
    todays_percentage = round((todays_present / todays_total) * 100, 1) if todays_total else 0.0

    trend = report_service.daily_attendance_trend(days=14)
    department_stats = report_service.department_wise_attendance()

    return render_template(
        "dashboard/admin_dashboard.html",
        total_students=total_students,
        total_teachers=total_teachers,
        total_subjects=total_subjects,
        todays_lectures=todays_lectures,
        todays_percentage=todays_percentage,
        trend=trend,
        department_stats=department_stats,
    )


@dashboard_bp.route("/dashboard/teacher")
@teacher_required
def teacher_dashboard():
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    teacher_id = teacher.id if teacher else None

    todays_lectures = lecture_service.get_today_lectures(teacher_id=teacher_id)
    upcoming_lectures = lecture_service.get_upcoming_lectures(teacher_id=teacher_id, limit=5)

    recent_attendance = (
        Attendance.query.join(Lecture, Attendance.lecture_id == Lecture.id)
        .filter(Lecture.teacher_id == teacher_id)
        .order_by(Attendance.marked_at.desc())
        .limit(10)
        .all()
    )

    return render_template(
        "dashboard/teacher_dashboard.html",
        teacher=teacher,
        todays_lectures=todays_lectures,
        upcoming_lectures=upcoming_lectures,
        recent_attendance=recent_attendance,
    )


@dashboard_bp.route("/dashboard/student")
@student_required
def student_dashboard():
    student = Student.query.filter_by(user_id=current_user.id).first()
    if not student:
        return render_template("dashboard/student_dashboard.html", student=None)

    summary = student_service.get_student_attendance_summary(student.id)
    recent_attendance = (
        Attendance.query.filter_by(student_id=student.id)
        .order_by(Attendance.marked_at.desc())
        .limit(10)
        .all()
    )

    return render_template(
        "dashboard/student_dashboard.html",
        student=student,
        summary=summary,
        recent_attendance=recent_attendance,
    )
