"""
routes/face_routes.py
JSON API for the face-registration workflow: uploading/capturing images,
rebuilding the recognition cache ("training"), and a standalone
detect+recognize test endpoint used by the take-attendance preview.
"""

import base64
import logging
import re

import cv2
import numpy as np

from extensions import csrf
from flask import Blueprint, jsonify, request
from flask_login import current_user

from ai_engine.embedding_manager import build_recognition_cache
from ai_engine.face_detector import FaceDetector, MultipleFacesDetectedError, NoFaceDetectedError
from ai_engine.face_encoder import FaceEncoder
from ai_engine.face_recognizer import FaceRecognizer
from database.db import db
from models.student import Student
from services import face_service
from utils.decorators import roles_required
from utils.image_utils import allowed_image_file, read_image_from_filestorage
from utils.validators import ValidationError

logger = logging.getLogger("smart_attendance.routes")
face_bp = Blueprint("face", __name__)

_DATA_URL_RE = re.compile(r"^data:image/\w+;base64,(.+)$")


def _decode_incoming_image():
    """Accept either a multipart file upload ('image' field) or a base64
    data-URL string ('image_data' field, produced by the webcam capture
    JS) and return an OpenCV BGR numpy array."""
    if "image" in request.files:
        file_storage = request.files["image"]
        if not allowed_image_file(file_storage.filename, {"png", "jpg", "jpeg", "webp"}):
            raise ValidationError("Unsupported image format. Use JPG, PNG, or WEBP.")
        image = read_image_from_filestorage(file_storage)
        if image is None:
            raise ValidationError("Could not decode the uploaded image.")
        return image

    payload = request.get_json(silent=True) or request.form
    image_data = payload.get("image_data") if payload else None
    if not image_data:
        raise ValidationError("No image was provided.")

    match = _DATA_URL_RE.match(image_data)
    raw_b64 = match.group(1) if match else image_data
    try:
        binary = base64.b64decode(raw_b64)
    except Exception:
        raise ValidationError("Invalid base64 image data.")

    array = np.frombuffer(binary, dtype=np.uint8)
    image = cv2.imdecode(array, cv2.IMREAD_COLOR)
    if image is None:
        raise ValidationError("Could not decode the captured webcam image.")
    return image


@csrf.exempt
@face_bp.route("/api/face/register", methods=["POST"])
@roles_required("admin", "teacher", "student")
def api_face_register():
    student_id = request.form.get("student_id") or (request.get_json(silent=True) or {}).get("student_id")
    if not student_id:
        return jsonify({"success": False, "message": "student_id is required."}), 400
    student_id = int(student_id)

    student = Student.query.get(student_id)
    if not student:
        return jsonify({"success": False, "message": "Student not found."}), 404
    if current_user.role == "student" and student.user_id != current_user.id:
        return jsonify({"success": False, "message": "Forbidden."}), 403

    try:
        image = _decode_incoming_image()
        result = face_service.register_face_image(student_id, image)
        progress = face_service.get_face_registration_progress(student_id)
        status_code = 200 if result.accepted else 422
        return jsonify({"success": result.accepted, "message": result.message, "progress": progress}), status_code
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@face_bp.route("/api/face/progress/<int:student_id>")
@roles_required("admin", "teacher", "student")
def api_face_progress(student_id):
    student = Student.query.get(student_id)
    if not student:
        return jsonify({"success": False, "message": "Student not found."}), 404
    return jsonify({"success": True, "progress": face_service.get_face_registration_progress(student_id)})


@csrf.exempt
@face_bp.route("/api/face/<int:face_data_id>", methods=["DELETE"])
@roles_required("admin", "teacher")
def api_face_delete(face_data_id):
    try:
        face_service.delete_face_image(face_data_id)
        return jsonify({"success": True, "message": "Face image removed."})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@face_bp.route("/api/face/train", methods=["POST"])
@roles_required("admin", "teacher")
def api_face_train():
    """Rebuild the in-memory recognition index from every stored embedding.
    Since we use a pre-trained ArcFace model (no from-scratch training),
    'training' here means refreshing the fast lookup cache used during
    classroom-photo recognition — call this after bulk-registering faces."""
    cache = build_recognition_cache(db_session=db.session, student_model=Student)
    return jsonify({"success": True, "message": "Recognition index rebuilt.", "students_indexed": len(cache)})


@csrf.exempt
@face_bp.route("/api/face/process", methods=["POST"])
@roles_required("admin", "teacher")
def api_face_process():
    """Standalone detect + recognize test on a single image, without
    touching attendance records. Useful for a quick demo/preview."""
    try:
        image = _decode_incoming_image()
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400

    detector = FaceDetector()
    encoder = FaceEncoder(detector=detector)
    recognizer = FaceRecognizer(db_session=db.session, student_model=Student)

    try:
        faces_with_embeddings = encoder.encode_all_faces(image)
    except (NoFaceDetectedError, MultipleFacesDetectedError) as exc:
        return jsonify({"success": False, "message": str(exc)}), 422

    if not faces_with_embeddings:
        return jsonify({"success": True, "faces": [], "message": "No face detected in the uploaded image."})

    embeddings = [e for _f, e in faces_with_embeddings]
    results = recognizer.identify_batch(embeddings)

    faces_payload = []
    for (face, _embedding), result in zip(faces_with_embeddings, results):
        entry = result.to_dict()
        entry["bbox"] = [round(v, 1) for v in face.bbox.tolist()]
        entry["det_score"] = round(face.det_score, 4)
        faces_payload.append(entry)

    return jsonify({"success": True, "faces": faces_payload})
