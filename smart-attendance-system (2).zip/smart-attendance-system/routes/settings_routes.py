"""
routes/settings_routes.py
Lets an admin tune the face-recognition similarity threshold and the
"mark absent if not detected" default without touching `.env` or
redeploying the app.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, url_for

from ai_engine import config as ai_config
from database.db import db
from models.settings import SystemSetting
from utils.decorators import admin_required

logger = logging.getLogger("smart_attendance.routes")
settings_bp = Blueprint("settings", __name__)


@settings_bp.route("/settings", methods=["GET", "POST"])
@admin_required
def settings_page():
    if request.method == "POST":
        threshold = request.form.get("face_similarity_threshold", type=float)
        default_absent = request.form.get("default_absent_if_not_detected") == "on"

        if threshold is not None and 0.0 <= threshold <= 1.0:
            SystemSetting.set_value("face_similarity_threshold", threshold)
            ai_config.DEFAULT_SIMILARITY_THRESHOLD = threshold

        SystemSetting.set_value("default_absent_if_not_detected", "true" if default_absent else "false")
        return redirect(url_for("settings.settings_page"))

    current_threshold = SystemSetting.get_value("face_similarity_threshold", str(ai_config.DEFAULT_SIMILARITY_THRESHOLD))
    default_absent = SystemSetting.get_value("default_absent_if_not_detected", "false") == "true"
    return render_template(
        "settings.html",
        current_threshold=float(current_threshold),
        default_absent=default_absent,
    )


@csrf.exempt
@settings_bp.route("/api/settings", methods=["GET"])
@admin_required
def api_get_settings():
    return jsonify(
        {
            "success": True,
            "face_similarity_threshold": float(
                SystemSetting.get_value("face_similarity_threshold", str(ai_config.DEFAULT_SIMILARITY_THRESHOLD))
            ),
            "default_absent_if_not_detected": SystemSetting.get_value("default_absent_if_not_detected", "false")
            == "true",
        }
    )


@csrf.exempt
@settings_bp.route("/api/settings", methods=["POST"])
@admin_required
def api_update_settings():
    data = request.get_json(silent=True) or {}
    if "face_similarity_threshold" in data:
        value = float(data["face_similarity_threshold"])
        if not (0.0 <= value <= 1.0):
            return jsonify({"success": False, "message": "Threshold must be between 0 and 1."}), 400
        SystemSetting.set_value("face_similarity_threshold", value)
        ai_config.DEFAULT_SIMILARITY_THRESHOLD = value
    if "default_absent_if_not_detected" in data:
        SystemSetting.set_value(
            "default_absent_if_not_detected", "true" if data["default_absent_if_not_detected"] else "false"
        )
    return jsonify({"success": True})
