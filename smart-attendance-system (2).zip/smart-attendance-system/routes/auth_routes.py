"""
routes/auth_routes.py
Session-based authentication (Flask-Login) for the HTML app, plus a
matching JSON API used by the SPA-style fetch calls in static/js/main.js.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required, login_user, logout_user
from werkzeug.security import generate_password_hash

from database.db import db
from models.settings import LoginLog
from models.student import Student
from models.teacher import Teacher
from models.user import User
from utils.decorators import admin_required
from utils.validators import ValidationError, validate_email, validate_password_strength, validate_role

logger = logging.getLogger("smart_attendance.routes")
auth_bp = Blueprint("auth", __name__)


def _dashboard_url_for_role(role):
    return {
        "admin": url_for("dashboard.admin_dashboard"),
        "teacher": url_for("dashboard.teacher_dashboard"),
        "student": url_for("dashboard.student_dashboard"),
    }.get(role, url_for("dashboard.admin_dashboard"))


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(_dashboard_url_for_role(current_user.role))

    if request.method == "GET":
        return render_template("login.html")

    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password") or ""
    remember = bool(request.form.get("remember"))

    user = User.query.filter_by(email=email).first()
    success = bool(user and user.is_active and user.check_password(password))

    db.session.add(LoginLog(email=email, success=success, ip_address=request.remote_addr))
    db.session.commit()

    if not success:
        return render_template("login.html", error="Invalid email or password.", email=email), 401

    login_user(user, remember=remember)
    session.permanent = True
    logger.info("User %s (%s) logged in", user.email, user.role)
    return redirect(_dashboard_url_for_role(user.role))


@auth_bp.route("/logout")
@login_required
def logout():
    logger.info("User %s logged out", current_user.email)
    logout_user()
    return redirect(url_for("auth.login"))


# --------------------------------------------------------------------- #
#  JSON API
# --------------------------------------------------------------------- #

@csrf.exempt
@auth_bp.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or request.form
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = User.query.filter_by(email=email).first()
    success = bool(user and user.is_active and user.check_password(password))

    db.session.add(LoginLog(email=email, success=success, ip_address=request.remote_addr))
    db.session.commit()

    if not success:
        return jsonify({"success": False, "message": "Invalid email or password."}), 401

    login_user(user)
    return jsonify({"success": True, "user": user.to_dict(), "redirect": _dashboard_url_for_role(user.role)})


@csrf.exempt
@auth_bp.route("/api/auth/logout", methods=["POST"])
@login_required
def api_logout():
    logout_user()
    return jsonify({"success": True})


@csrf.exempt
@auth_bp.route("/api/auth/register", methods=["POST"])
@admin_required
def api_register():
    """Admin-only endpoint to create a new user of any role. Student/
    teacher-specific profile fields are optional here; the dedicated
    /api/students and /api/teachers endpoints are the primary way those
    profiles get created (and call this same logic internally)."""
    data = request.get_json(silent=True) or request.form
    try:
        full_name = (data.get("full_name") or "").strip()
        if not full_name:
            raise ValidationError("Full name is required.")
        email = validate_email(data.get("email"))
        password = validate_password_strength(data.get("password"))
        role = validate_role(data.get("role"))

        if User.query.filter_by(email=email).first():
            raise ValidationError(f"A user with email {email} already exists.")

        user = User(full_name=full_name, email=email, password_hash=generate_password_hash(password), role=role)
        db.session.add(user)
        db.session.commit()
        return jsonify({"success": True, "user": user.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@auth_bp.route("/api/auth/me")
@login_required
def api_me():
    return jsonify({"success": True, "user": current_user.to_dict()})
