"""
routes/teacher_routes.py
Admin-facing teacher account management plus JSON API.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

from database.db import db
from models.teacher import Teacher
from models.user import User
from utils.decorators import admin_required
from utils.validators import ValidationError, require_fields, validate_email, validate_password_strength

logger = logging.getLogger("smart_attendance.routes")
teacher_bp = Blueprint("teachers", __name__)


def _create_teacher(data: dict) -> Teacher:
    require_fields(data, ["full_name", "email", "employee_id", "department"])
    full_name = data["full_name"].strip()
    email = validate_email(data["email"])
    employee_id = data["employee_id"].strip()
    department = data["department"].strip()
    password = data.get("password") or employee_id

    if User.query.filter_by(email=email).first():
        raise ValidationError(f"A user with email {email} already exists.")
    if Teacher.query.filter_by(employee_id=employee_id).first():
        raise ValidationError(f"A teacher with employee ID {employee_id} already exists.")

    validate_password_strength(password)
    user = User(full_name=full_name, email=email, password_hash=generate_password_hash(password), role="teacher")
    db.session.add(user)
    db.session.flush()

    teacher = Teacher(user_id=user.id, employee_id=employee_id, department=department)
    db.session.add(teacher)
    db.session.commit()
    logger.info("Created teacher %s (%s)", employee_id, email)
    return teacher


@teacher_bp.route("/teachers")
@admin_required
def teacher_list():
    teachers = Teacher.query.join(User).order_by(User.full_name.asc()).all()
    return render_template("teachers/teacher_list.html", teachers=teachers)


@teacher_bp.route("/teachers/new", methods=["GET", "POST"])
@admin_required
def teacher_new():
    if request.method == "GET":
        return render_template("teachers/teacher_form.html")
    try:
        _create_teacher(request.form.to_dict())
    except ValidationError as exc:
        return render_template("teachers/teacher_form.html", error=str(exc), form=request.form), 400
    return redirect(url_for("teachers.teacher_list"))


@teacher_bp.route("/teachers/<int:teacher_id>/delete", methods=["POST"])
@admin_required
def teacher_delete(teacher_id):
    teacher = Teacher.query.get_or_404(teacher_id)
    user = teacher.user
    db.session.delete(teacher)
    if user:
        db.session.delete(user)
    db.session.commit()
    return redirect(url_for("teachers.teacher_list"))


@csrf.exempt
@teacher_bp.route("/api/teachers", methods=["GET"])
@admin_required
def api_list_teachers():
    teachers = Teacher.query.join(User).order_by(User.full_name.asc()).all()
    return jsonify({"success": True, "teachers": [t.to_dict() for t in teachers]})


@csrf.exempt
@teacher_bp.route("/api/teachers", methods=["POST"])
@admin_required
def api_create_teacher():
    data = request.get_json(silent=True) or request.form
    try:
        teacher = _create_teacher(data)
        return jsonify({"success": True, "teacher": teacher.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@teacher_bp.route("/api/teachers/<int:teacher_id>", methods=["DELETE"])
@admin_required
def api_delete_teacher(teacher_id):
    teacher = Teacher.query.get(teacher_id)
    if not teacher:
        return jsonify({"success": False, "message": "Teacher not found."}), 404
    user = teacher.user
    db.session.delete(teacher)
    if user:
        db.session.delete(user)
    db.session.commit()
    return jsonify({"success": True, "message": "Teacher deleted."})
