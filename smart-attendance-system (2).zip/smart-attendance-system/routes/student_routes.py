"""
routes/student_routes.py
Admin-facing student management (add/edit/delete/search/profile) plus the
JSON API consumed by static/js/main.js.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from ai_engine import config as ai_config
from models.attendance import FaceData
from models.student import Student
from services import face_service, student_service
from utils.decorators import admin_required, roles_required
from utils.validators import ValidationError

logger = logging.getLogger("smart_attendance.routes")
student_bp = Blueprint("students", __name__)


# --------------------------------------------------------------------- #
#  HTML pages
# --------------------------------------------------------------------- #

@student_bp.route("/students")
@roles_required("admin", "teacher")
def student_list():
    query = request.args.get("q", "")
    department = request.args.get("department", "")
    semester = request.args.get("semester", type=int)
    division = request.args.get("division", "")
    page = request.args.get("page", 1, type=int)

    pagination = student_service.search_students(
        query=query, department=department, semester=semester, division=division, page=page
    )
    departments = [d[0] for d in Student.query.with_entities(Student.department).distinct().all()]

    return render_template(
        "students/student_list.html",
        pagination=pagination,
        students=pagination.items,
        departments=departments,
        filters={"q": query, "department": department, "semester": semester, "division": division},
    )


@student_bp.route("/students/new", methods=["GET", "POST"])
@admin_required
def student_new():
    if request.method == "GET":
        return render_template("students/student_form.html", student=None)

    try:
        student = student_service.create_student(request.form.to_dict())
    except ValidationError as exc:
        return render_template("students/student_form.html", student=None, error=str(exc), form=request.form), 400

    return redirect(url_for("students.face_registration_page", student_id=student.id))


@student_bp.route("/students/<int:student_id>/edit", methods=["GET", "POST"])
@admin_required
def student_edit(student_id):
    student = Student.query.get_or_404(student_id)

    if request.method == "GET":
        return render_template("students/student_form.html", student=student)

    try:
        student_service.update_student(student_id, request.form.to_dict())
    except ValidationError as exc:
        return render_template("students/student_form.html", student=student, error=str(exc)), 400

    return redirect(url_for("students.student_profile", student_id=student_id))


@student_bp.route("/students/<int:student_id>/delete", methods=["POST"])
@admin_required
def student_delete(student_id):
    try:
        student_service.delete_student(student_id)
    except ValidationError as exc:
        return render_template("students/student_list.html", error=str(exc)), 400
    return redirect(url_for("students.student_list"))


@student_bp.route("/students/<int:student_id>")
@roles_required("admin", "teacher", "student")
def student_profile(student_id):
    student = Student.query.get_or_404(student_id)
    if current_user.role == "student" and student.user_id != current_user.id:
        return render_template("errors/403.html"), 403

    summary = student_service.get_student_attendance_summary(student_id)
    face_images = FaceData.query.filter_by(student_id=student_id).all()

    from models.attendance import Attendance
    history = (
        Attendance.query.filter_by(student_id=student_id)
        .join(Attendance.lecture)
        .order_by(Attendance.marked_at.desc())
        .all()
    )

    return render_template(
        "students/student_profile.html",
        student=student,
        summary=summary,
        face_images=face_images,
        history=history,
    )


@student_bp.route("/students/<int:student_id>/face-registration")
@roles_required("admin", "teacher", "student")
def face_registration_page(student_id):
    student = Student.query.get_or_404(student_id)
    progress = face_service.get_face_registration_progress(student_id)
    return render_template(
        "students/face_registration.html",
        student=student,
        progress=progress,
        max_images=ai_config.MAX_FACE_IMAGES_ALLOWED,
    )


# --------------------------------------------------------------------- #
#  JSON API
# --------------------------------------------------------------------- #

@csrf.exempt
@student_bp.route("/api/students", methods=["GET"])
@roles_required("admin", "teacher")
def api_list_students():
    pagination = student_service.search_students(
        query=request.args.get("q", ""),
        department=request.args.get("department", ""),
        semester=request.args.get("semester", type=int),
        division=request.args.get("division", ""),
        page=request.args.get("page", 1, type=int),
        per_page=request.args.get("per_page", 20, type=int),
    )
    return jsonify(
        {
            "success": True,
            "students": [s.to_dict() for s in pagination.items],
            "total": pagination.total,
            "page": pagination.page,
            "pages": pagination.pages,
        }
    )


@csrf.exempt
@student_bp.route("/api/students", methods=["POST"])
@admin_required
def api_create_student():
    data = request.get_json(silent=True) or request.form
    try:
        student = student_service.create_student(data)
        return jsonify({"success": True, "student": student.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@student_bp.route("/api/students/<int:student_id>", methods=["GET"])
@roles_required("admin", "teacher", "student")
def api_get_student(student_id):
    student = Student.query.get(student_id)
    if not student:
        return jsonify({"success": False, "message": "Student not found."}), 404
    if current_user.role == "student" and student.user_id != current_user.id:
        return jsonify({"success": False, "message": "Forbidden."}), 403
    return jsonify({"success": True, "student": student.to_dict()})


@csrf.exempt
@student_bp.route("/api/students/<int:student_id>", methods=["PUT", "PATCH"])
@admin_required
def api_update_student(student_id):
    data = request.get_json(silent=True) or request.form
    try:
        student = student_service.update_student(student_id, data)
        return jsonify({"success": True, "student": student.to_dict()})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@student_bp.route("/api/students/<int:student_id>", methods=["DELETE"])
@admin_required
def api_delete_student(student_id):
    try:
        student_service.delete_student(student_id)
        return jsonify({"success": True, "message": "Student deleted."})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@student_bp.route("/api/students/<int:student_id>/attendance-summary")
@roles_required("admin", "teacher", "student")
def api_student_attendance_summary(student_id):
    student = Student.query.get(student_id)
    if not student:
        return jsonify({"success": False, "message": "Student not found."}), 404
    if current_user.role == "student" and student.user_id != current_user.id:
        return jsonify({"success": False, "message": "Forbidden."}), 403
    return jsonify({"success": True, "summary": student_service.get_student_attendance_summary(student_id)})
