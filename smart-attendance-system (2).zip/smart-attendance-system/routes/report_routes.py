"""
routes/report_routes.py
Filterable attendance reports for admins/teachers, with CSV, Excel, and
PDF export.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, render_template, request, send_file

from models.student import Student
from models.subject import Subject
from services import report_service
from utils.decorators import roles_required

logger = logging.getLogger("smart_attendance.routes")
report_bp = Blueprint("reports", __name__)


def _read_filters():
    return {
        "student_id": request.args.get("student_id", type=int),
        "subject_id": request.args.get("subject_id", type=int),
        "department": request.args.get("department") or None,
        "semester": request.args.get("semester", type=int),
        "division": request.args.get("division") or None,
        "date_from": request.args.get("date_from") or None,
        "date_to": request.args.get("date_to") or None,
    }


@report_bp.route("/reports")
@roles_required("admin", "teacher")
def reports_page():
    filters = _read_filters()
    rows = report_service.build_report_rows(**filters)
    percentage_report = report_service.student_percentage_report(
        department=filters["department"], semester=filters["semester"], division=filters["division"]
    )
    subjects = Subject.query.order_by(Subject.subject_name.asc()).all()
    departments = [d[0] for d in Student.query.with_entities(Student.department).distinct().all()]

    return render_template(
        "reports/reports.html",
        rows=rows,
        percentage_report=percentage_report,
        subjects=subjects,
        departments=departments,
        filters=filters,
    )


@csrf.exempt
@report_bp.route("/api/reports")
@roles_required("admin", "teacher")
def api_reports():
    filters = _read_filters()
    rows = report_service.build_report_rows(**filters)
    return jsonify({"success": True, "rows": rows, "count": len(rows)})


@csrf.exempt
@report_bp.route("/api/reports/student-percentage")
@roles_required("admin", "teacher")
def api_student_percentage_report():
    filters = _read_filters()
    report = report_service.student_percentage_report(
        department=filters["department"], semester=filters["semester"], division=filters["division"]
    )
    return jsonify({"success": True, "report": report})


@csrf.exempt
@report_bp.route("/api/reports/subject-wise")
@roles_required("admin", "teacher")
def api_subject_wise_report():
    subject_id = request.args.get("subject_id", type=int)
    report = report_service.subject_wise_report(subject_id=subject_id)
    return jsonify({"success": True, "report": report})


@csrf.exempt
@report_bp.route("/api/reports/export")
@roles_required("admin", "teacher")
def api_export_report():
    export_format = request.args.get("format", "csv").lower()
    filters = _read_filters()
    rows = report_service.build_report_rows(**filters)

    if export_format == "csv":
        buffer = report_service.export_to_csv(rows)
        return send_file(buffer, mimetype="text/csv", as_attachment=True, download_name="attendance_report.csv")
    if export_format == "excel":
        buffer = report_service.export_to_excel(rows)
        return send_file(
            buffer,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name="attendance_report.xlsx",
        )
    if export_format == "pdf":
        buffer = report_service.export_to_pdf(rows, title="Attendance Report")
        return send_file(buffer, mimetype="application/pdf", as_attachment=True, download_name="attendance_report.pdf")

    return jsonify({"success": False, "message": "format must be one of: csv, excel, pdf"}), 400
