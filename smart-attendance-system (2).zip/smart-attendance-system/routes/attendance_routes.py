"""
routes/attendance_routes.py
The core classroom-attendance workflow:
  1. GET  /attendance/take/<lecture_id>      -> upload/camera page
  2. POST /api/attendance/process            -> run AI on the photo
  3. GET  /attendance/result/<lecture_id>    -> review page (boxes + roster)
  4. POST /api/attendance/manual             -> teacher correction
  5. POST /api/attendance/confirm            -> finalize the lecture
  6. GET  /attendance/history                -> past attendance browsing
"""

import logging
import os

from extensions import csrf
from flask import Blueprint, current_app, jsonify, redirect, render_template, request, url_for
from flask_login import current_user

from ai_engine import config as ai_config
from models.attendance import Attendance, AttendanceImage
from models.lecture import Lecture
from models.settings import SystemSetting
from models.student import Student
from services import attendance_service
from utils.decorators import roles_required
from utils.image_utils import allowed_image_file, generate_unique_filename, save_image, read_image_from_filestorage
from utils.validators import ValidationError, validate_status

logger = logging.getLogger("smart_attendance.routes")
attendance_bp = Blueprint("attendance", __name__)


def _resolve_default_absent() -> bool:
    stored = SystemSetting.get_value("default_absent_if_not_detected")
    if stored is not None:
        return stored.strip().lower() == "true"
    return bool(current_app.config.get("DEFAULT_ABSENT_IF_NOT_DETECTED", False))


def _resolve_similarity_threshold() -> float:
    stored = SystemSetting.get_value("face_similarity_threshold")
    if stored:
        try:
            return float(stored)
        except ValueError:
            pass
    return float(current_app.config.get("FACE_SIMILARITY_THRESHOLD", 0.45))


# --------------------------------------------------------------------- #
#  HTML pages
# --------------------------------------------------------------------- #

@attendance_bp.route("/attendance/take/<int:lecture_id>")
@roles_required("admin", "teacher")
def take_attendance_page(lecture_id):
    lecture = Lecture.query.get_or_404(lecture_id)
    return render_template("attendance/take_attendance.html", lecture=lecture)


@attendance_bp.route("/attendance/result/<int:lecture_id>")
@roles_required("admin", "teacher")
def attendance_result_page(lecture_id):
    lecture = Lecture.query.get_or_404(lecture_id)
    roster = attendance_service.get_lecture_attendance(lecture_id)
    latest_image = (
        AttendanceImage.query.filter_by(lecture_id=lecture_id).order_by(AttendanceImage.uploaded_at.desc()).first()
    )
    stats = {
        "total_enrolled": len(roster),
        "present": sum(1 for r in roster if r["status"] in ("Present", "Manual Present")),
        "pending": sum(1 for r in roster if r["status"] == "Pending"),
        "absent": sum(1 for r in roster if r["status"] == "Absent"),
    }
    return render_template(
        "attendance/attendance_result.html",
        lecture=lecture,
        roster=roster,
        latest_image=latest_image,
        stats=stats,
    )


@attendance_bp.route("/attendance/manual/<int:lecture_id>")
@roles_required("admin", "teacher")
def manual_attendance_page(lecture_id):
    lecture = Lecture.query.get_or_404(lecture_id)
    roster = attendance_service.get_lecture_attendance(lecture_id)
    return render_template("attendance/manual_attendance.html", lecture=lecture, roster=roster)


@attendance_bp.route("/attendance/history")
@roles_required("admin", "teacher", "student")
def attendance_history_page():
    if current_user.role == "student":
        student = Student.query.filter_by(user_id=current_user.id).first()
        records = (
            Attendance.query.filter_by(student_id=student.id).order_by(Attendance.marked_at.desc()).limit(200).all()
            if student
            else []
        )
    else:
        records = Attendance.query.order_by(Attendance.marked_at.desc()).limit(200).all()
    return render_template("attendance/attendance_history.html", records=records)


# --------------------------------------------------------------------- #
#  JSON API
# --------------------------------------------------------------------- #

@csrf.exempt
@attendance_bp.route("/api/attendance/process", methods=["POST"])
@roles_required("admin", "teacher")
def api_process_attendance():
    lecture_id = request.form.get("lecture_id", type=int) or (request.get_json(silent=True) or {}).get("lecture_id")
    if not lecture_id:
        return jsonify({"success": False, "message": "lecture_id is required."}), 400

    if "image" not in request.files:
        return jsonify({"success": False, "message": "A classroom image file is required."}), 400

    file_storage = request.files["image"]
    if not allowed_image_file(file_storage.filename, current_app.config["ALLOWED_IMAGE_EXTENSIONS"]):
        return jsonify({"success": False, "message": "Unsupported image format. Use JPG, PNG, or WEBP."}), 400

    try:
        image = read_image_from_filestorage(file_storage)
        if image is None:
            return jsonify({"success": False, "message": "Could not decode the uploaded image."}), 400

        filename = generate_unique_filename(file_storage.filename, prefix=f"lecture{lecture_id}")
        saved_path = save_image(image, ai_config.CLASSROOM_IMAGE_FOLDER, filename)

        result = attendance_service.process_classroom_photo(
            lecture_id=int(lecture_id),
            image_path=saved_path,
            uploaded_by=current_user.id,
            similarity_threshold=_resolve_similarity_threshold(),
        )
        attendance_service.finalize_absentees(
            lecture_id=int(lecture_id),
            recognized_student_ids=result["recognized_student_ids"],
            default_absent=_resolve_default_absent(),
        )

        result["processed_image_url"] = url_for(
            "attendance.serve_processed_image", filename=os.path.basename(result["processed_image_path"])
        )
        return jsonify({"success": True, "result": result})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400
    except Exception:
        logger.exception("Failed to process classroom image for lecture %s", lecture_id)
        return jsonify({"success": False, "message": "AI processing failed. Please check server logs."}), 500


@attendance_bp.route("/attendance/processed-image/<path:filename>")
@roles_required("admin", "teacher")
def serve_processed_image(filename):
    from flask import send_from_directory

    return send_from_directory(ai_config.PROCESSED_IMAGE_FOLDER, filename)


@csrf.exempt
@attendance_bp.route("/api/attendance/manual", methods=["POST"])
@roles_required("admin", "teacher")
def api_manual_attendance():
    data = request.get_json(silent=True) or request.form
    try:
        lecture_id = int(data["lecture_id"])
        student_id = int(data["student_id"])
        status = validate_status(data.get("status"))
    except (KeyError, ValueError, TypeError):
        return jsonify({"success": False, "message": "lecture_id, student_id and status are required."}), 400
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400

    try:
        record = attendance_service.manual_mark_attendance(lecture_id, student_id, status, current_user.id)
        return jsonify({"success": True, "attendance": record.to_dict()})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@attendance_bp.route("/api/attendance/remove-detection", methods=["POST"])
@roles_required("admin", "teacher")
def api_remove_detection():
    data = request.get_json(silent=True) or request.form
    try:
        attendance_id = int(data["attendance_id"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"success": False, "message": "attendance_id is required."}), 400

    try:
        record = attendance_service.remove_incorrect_detection(attendance_id, current_user.id)
        return jsonify({"success": True, "attendance": record.to_dict()})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@attendance_bp.route("/api/attendance/confirm", methods=["POST"])
@roles_required("admin", "teacher")
def api_confirm_attendance():
    data = request.get_json(silent=True) or request.form
    try:
        lecture_id = int(data["lecture_id"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"success": False, "message": "lecture_id is required."}), 400

    try:
        lecture = attendance_service.confirm_attendance(lecture_id, current_user.id)
        return jsonify({"success": True, "lecture": lecture.to_dict()})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@attendance_bp.route("/api/attendance/lecture/<int:lecture_id>")
@roles_required("admin", "teacher")
def api_lecture_attendance(lecture_id):
    try:
        roster = attendance_service.get_lecture_attendance(lecture_id)
        return jsonify({"success": True, "roster": roster})
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 404
