"""
routes/subject_routes.py
CRUD for subjects/courses offered by the university.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, url_for

from database.db import db
from models.subject import Subject
from utils.decorators import admin_required, roles_required
from utils.validators import ValidationError, require_fields, validate_semester

logger = logging.getLogger("smart_attendance.routes")
subject_bp = Blueprint("subjects", __name__)


def _create_subject(data: dict) -> Subject:
    require_fields(data, ["subject_name", "subject_code", "semester", "department"])
    subject_code = data["subject_code"].strip().upper()
    if Subject.query.filter_by(subject_code=subject_code).first():
        raise ValidationError(f"Subject code {subject_code} already exists.")

    subject = Subject(
        subject_name=data["subject_name"].strip(),
        subject_code=subject_code,
        semester=validate_semester(data["semester"]),
        department=data["department"].strip(),
    )
    db.session.add(subject)
    db.session.commit()
    return subject


@subject_bp.route("/subjects")
@roles_required("admin", "teacher")
def subject_list():
    subjects = Subject.query.order_by(Subject.department.asc(), Subject.semester.asc()).all()
    return render_template("subjects/subject_list.html", subjects=subjects)


@subject_bp.route("/subjects/new", methods=["GET", "POST"])
@admin_required
def subject_new():
    if request.method == "GET":
        return render_template("subjects/subject_form.html")
    try:
        _create_subject(request.form.to_dict())
    except ValidationError as exc:
        return render_template("subjects/subject_form.html", error=str(exc), form=request.form), 400
    return redirect(url_for("subjects.subject_list"))


@subject_bp.route("/subjects/<int:subject_id>/delete", methods=["POST"])
@admin_required
def subject_delete(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    db.session.delete(subject)
    db.session.commit()
    return redirect(url_for("subjects.subject_list"))


@csrf.exempt
@subject_bp.route("/api/subjects", methods=["GET"])
@roles_required("admin", "teacher")
def api_list_subjects():
    subjects = Subject.query.order_by(Subject.subject_name.asc()).all()
    return jsonify({"success": True, "subjects": [s.to_dict() for s in subjects]})


@csrf.exempt
@subject_bp.route("/api/subjects", methods=["POST"])
@admin_required
def api_create_subject():
    data = request.get_json(silent=True) or request.form
    try:
        subject = _create_subject(data)
        return jsonify({"success": True, "subject": subject.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@subject_bp.route("/api/subjects/<int:subject_id>", methods=["DELETE"])
@admin_required
def api_delete_subject(subject_id):
    subject = Subject.query.get(subject_id)
    if not subject:
        return jsonify({"success": False, "message": "Subject not found."}), 404
    db.session.delete(subject)
    db.session.commit()
    return jsonify({"success": True, "message": "Subject deleted."})
