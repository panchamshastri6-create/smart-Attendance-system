"""
routes/lecture_routes.py
Scheduling lectures (class sessions) and managing physical classrooms.
"""

import logging

from extensions import csrf
from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import current_user

from database.db import db
from models.lecture import Classroom, Lecture
from models.subject import Subject
from models.teacher import Teacher
from services import lecture_service
from utils.decorators import admin_required, roles_required
from utils.validators import ValidationError, require_fields

logger = logging.getLogger("smart_attendance.routes")
lecture_bp = Blueprint("lectures", __name__)


# --------------------------------------------------------------------- #
#  Classrooms
# --------------------------------------------------------------------- #

@lecture_bp.route("/classrooms")
@admin_required
def classroom_list():
    classrooms = Classroom.query.order_by(Classroom.building_name.asc()).all()
    return render_template("lectures/classroom_list.html", classrooms=classrooms)


@lecture_bp.route("/classrooms/new", methods=["GET", "POST"])
@admin_required
def classroom_new():
    if request.method == "GET":
        return render_template("lectures/classroom_form.html")

    data = request.form.to_dict()
    try:
        require_fields(data, ["room_name", "building_name"])
        if Classroom.query.filter_by(room_name=data["room_name"], building_name=data["building_name"]).first():
            raise ValidationError("This classroom already exists.")
        classroom = Classroom(
            room_name=data["room_name"].strip(),
            building_name=data["building_name"].strip(),
            capacity=int(data.get("capacity") or 0),
        )
        db.session.add(classroom)
        db.session.commit()
    except ValidationError as exc:
        return render_template("lectures/classroom_form.html", error=str(exc), form=data), 400

    return redirect(url_for("lectures.classroom_list"))


@csrf.exempt
@lecture_bp.route("/api/classrooms", methods=["GET"])
@roles_required("admin", "teacher")
def api_list_classrooms():
    classrooms = Classroom.query.order_by(Classroom.building_name.asc()).all()
    return jsonify({"success": True, "classrooms": [c.to_dict() for c in classrooms]})


@csrf.exempt
@lecture_bp.route("/api/classrooms", methods=["POST"])
@admin_required
def api_create_classroom():
    data = request.get_json(silent=True) or request.form
    try:
        require_fields(data, ["room_name", "building_name"])
        classroom = Classroom(
            room_name=data["room_name"].strip(),
            building_name=data["building_name"].strip(),
            capacity=int(data.get("capacity") or 0),
        )
        db.session.add(classroom)
        db.session.commit()
        return jsonify({"success": True, "classroom": classroom.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


# --------------------------------------------------------------------- #
#  Lectures
# --------------------------------------------------------------------- #

@lecture_bp.route("/lectures")
@roles_required("admin", "teacher")
def lecture_list():
    teacher_filter = None
    if current_user.role == "teacher":
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        teacher_filter = teacher.id if teacher else None

    page = request.args.get("page", 1, type=int)
    pagination = lecture_service.get_lectures(teacher_id=teacher_filter, page=page)
    return render_template("lectures/lecture_list.html", pagination=pagination, lectures=pagination.items)


@lecture_bp.route("/lectures/new", methods=["GET", "POST"])
@roles_required("admin", "teacher")
def lecture_new():
    subjects = Subject.query.order_by(Subject.subject_name.asc()).all()
    teachers = Teacher.query.join(Teacher.user).order_by(Teacher.department.asc()).all()
    classrooms = Classroom.query.order_by(Classroom.building_name.asc()).all()

    if request.method == "GET":
        default_teacher = None
        if current_user.role == "teacher":
            default_teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        return render_template(
            "lectures/create_lecture.html",
            subjects=subjects,
            teachers=teachers,
            classrooms=classrooms,
            default_teacher=default_teacher,
        )

    data = request.form.to_dict()
    if current_user.role == "teacher":
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        if teacher:
            data["teacher_id"] = teacher.id

    try:
        lecture = lecture_service.create_lecture(data)
    except ValidationError as exc:
        return render_template(
            "lectures/create_lecture.html",
            subjects=subjects,
            teachers=teachers,
            classrooms=classrooms,
            error=str(exc),
            form=data,
        ), 400

    return redirect(url_for("attendance.take_attendance_page", lecture_id=lecture.id))


@csrf.exempt
@lecture_bp.route("/api/lectures", methods=["GET"])
@roles_required("admin", "teacher")
def api_list_lectures():
    teacher_id = request.args.get("teacher_id", type=int)
    subject_id = request.args.get("subject_id", type=int)
    page = request.args.get("page", 1, type=int)
    pagination = lecture_service.get_lectures(teacher_id=teacher_id, subject_id=subject_id, page=page)
    return jsonify(
        {
            "success": True,
            "lectures": [l.to_dict() for l in pagination.items],
            "total": pagination.total,
            "page": pagination.page,
            "pages": pagination.pages,
        }
    )


@csrf.exempt
@lecture_bp.route("/api/lectures", methods=["POST"])
@roles_required("admin", "teacher")
def api_create_lecture():
    data = request.get_json(silent=True) or request.form
    try:
        lecture = lecture_service.create_lecture(data)
        return jsonify({"success": True, "lecture": lecture.to_dict()}), 201
    except ValidationError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@csrf.exempt
@lecture_bp.route("/api/lectures/<int:lecture_id>", methods=["GET"])
@roles_required("admin", "teacher")
def api_get_lecture(lecture_id):
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        return jsonify({"success": False, "message": "Lecture not found."}), 404
    return jsonify({"success": True, "lecture": lecture.to_dict()})
